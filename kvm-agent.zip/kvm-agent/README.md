# kvm-agent

A local Go agent for the vendor video-application that ships with the
Epiphan KVM2USB 3.0: capture the vendor's video viewport, send the frame to
an image-capable LLM, interpret visible system state, propose a keyboard or
mouse action, capture the result and persist everything as evidence on disk.

The browser interface binds to `127.0.0.1` only. Everything else happens
locally.

## Overview

`kvm-agent` does the same job the old Python wrapper did, but is written
from scratch in Go and depends only on the operating system and the
standard library. It does **not** embed or call into any third-party KVM
SDK or driver; it only talks to the vendor's own video-application window
through standard X11 and to the user-provided vision endpoint over
HTTPS. Hardware access is mediated by a single, narrowly-scoped udev rule
the user installs explicitly with the supplied helper script.

| Backend      | Capture transport                                   | UX |
|--------------|---------------------------------------------------|----|
| `demo`       | Synthetic frame rendered in-process              | Hardware-free, no setup |
| `kvmapp`     | X11 GetImage on the vendor's video viewport      | Drives the vendor GUI via XTEST |

For turning a fresh Ubuntu 24.04.4 Desktop install into a working
bench (disable Wayland, install tesseract, install the udev rule,
configure autologin, …), see [BENCH_SETUP.md](BENCH_SETUP.md). For
authoring a test from an operator spec and deploying it to Rundeck,
see [TEST_HANDOFF.md](TEST_HANDOFF.md).

## Prerequisites

- Linux x86_64 with an Xorg desktop session.
- The vendor's video-application available at `vendor/KvmApp` inside the
  bundle (see the *Bundle layout* section for how it gets there).
- A vision endpoint reachable via `http(s)://` that accepts the OpenAI
  `/chat/completions` schema with image URLs. Configure it through the UI
  or `KVM_VISION_URL` / `KVM_VISION_MODEL` (and optionally
  `KVM_VISION_API_KEY`).

Wayland is intentionally rejected by the vendor backend: the vendor
application forwards hotkeys and live input through XTEST, and the
application does not work under XWayland.

## Building and running

The project is pure Go and uses only the standard library.

```sh
go build -o kvm-agent ./cmd/kvm-agent
./kvm-agent doctor
./kvm-agent serve --port 8765
```

The doctor command reports which `/dev/videoN` nodes exist, which
top-level X11 windows look like the vendor application, and what
session type is active.

## CLI

```sh
./kvm-agent doctor
./kvm-agent demo
./kvm-agent launch
./kvm-agent capture --backend kvmapp \
    --window-id 0x123456 --viewport 0 45 1280 720 \
    --session-root ~/.local/state/kvm-agent/sessions
./kvm-agent inspect --backend kvmapp --window-id 0x123456 \
    --viewport 0 45 1280 720 \
    --vision-url http://127.0.0.1:8000/v1 \
    --model your-vision-model \
    --goal 'Describe the visible firmware state'
./kvm-agent run --backend kvmapp --window-id 0x123456 \
    --viewport 0 45 1280 720 \
    --vision-url http://127.0.0.1:8000/v1 \
    --model your-vision-model \
    --goal 'Open the boot menu' \
    --max-steps 5 --execute
```

`run` only observes and proposes by default. Add `--execute` to dispatch
proposals whose confidence is at or above `--min-confidence` (0.8 by
default). API keys are accepted from `KVM_VISION_API_KEY`; never put them
into committed scripts or configuration.

## Local web UI

```sh
./kvm-agent serve --port 8765
```

The server binds to `127.0.0.1:8765`, opens the default browser, and serves
a single-page UI that mirrors the CLI commands. A per-launch CSRF token
is generated and must accompany every `POST /api/*` request. Captured
PNGs are served through `/image/<id>` so the UI can render the latest
frame and the active proposal as a rectangle over it.


## OCR and deterministic text checks

The vision LLM is great for navigating unfamiliar UIs but is the wrong
choice for a CI pass/fail test. `kvm-agent` ships an OCR + deterministic
text-assertion path built around the system `tesseract` binary (install
`tesseract-ocr` and a language pack like `tesseract-ocr-eng` from your
distribution's package manager).

```sh
# Capture one frame and include OCR text in the output JSON.
kvm-agent capture --backend kvmapp     --window-id 0x12345 --viewport 0 45 1280 720     --ocr > /tmp/cap.json

# Same capture, but fail (exit 1) if the OCR text does not contain
# "Samsung SSD 980 PRO". --check-pattern can be repeated.
kvm-agent capture --backend kvmapp     --window-id 0x12345 --viewport 0 45 1280 720     --check-pattern 'Samsung SSD 980 PRO'

# Case-insensitive AND-of-patterns assertion.
kvm-agent capture --backend kvmapp     --window-id 0x12345 --viewport 0 45 1280 720     --check-pattern 'Storage Configuration'     --check-pattern 'NVMe' --all-patterns --case-insensitive

# Pipeline form: capture once, save OCR JSON, then assert in a separate
# Rundeck step.
kvm-agent capture --backend kvmapp     --window-id 0x12345 --viewport 0 45 1280 720     --ocr --save-ocr-json /tmp/cap-ocr.json     --session-root /var/lib/rundeck/kvm

kvm-agent check-text     --from-json /tmp/cap-ocr.json     --pattern 'Samsung SSD 980 PRO'
# exit 0 = match, 1 = miss, 2 = bad input
```

Both `capture --check-pattern` and `check-text` print a JSON result with
the matched pattern, position, captured text length and the overall
`matched` boolean. They return exit 0 on success and exit 1 on
failure, so a Rundeck job step's native exit-code check works without
extra scripting. Patterns are Go regular expressions; add `(?i)` or
`--case-insensitive` to fold case.

## Entering the BIOS without a BMC

For targets that do not expose IPMI / Redfish the operator has to power
the machine on by hand. `boot-into-bios` covers the part the operator
cannot: it spams a boot-menu key (commonly DEL or F2) repeatedly while
OCR-ing each captured frame, and exits as soon as the recognised text
matches the supplied regex (or after a timeout).

```sh
# Press DEL every 250 ms; once OCR sees "Setup Utility" / "BIOS Setup"
# / "Save & Exit" (case-insensitive), the command exits 0.
kvm-agent boot-into-bios     --backend kvmapp     --window-id 0x12345 --viewport 0 45 1280 720     --key delete     --match-text 'Setup Utility'     --match-text 'Save & Exit'     --interval 250ms     --timeout 60s
```

The defaults (`--key delete`, `--interval 250ms`, `--timeout 45s`,
fallback match list "Setup Utility | BIOS Setup | Save & Exit") match
most AMI / Award / Insyde UEFI firmwares. Override per board.

A typical Rundeck flow looks like:

```sh
# 1. Operator powers the target on by hand and starts this job.
# 2. Wait for BIOS to appear via blind DEL spam.
kvm-agent boot-into-bios --backend kvmapp ...     --match-text 'Setup Utility' --timeout 60s || exit 1

# 3. Navigate to the storage menu by sending key presses.
#    Each call captures, presses the key, and re-captures to log evidence.
for key in right right down; do
    kvm-agent capture --backend kvmapp ...         --check-pattern 'BIOS Setup Utility|Storage'         --check-pattern "$key"
    kvm-agent capture --backend kvmapp ...         --enable-input --save-act "$key"
done

# 4. Assert the NVMe device is listed.
kvm-agent capture --backend kvmapp ...     --check-pattern 'Samsung SSD 980 PRO' --case-insensitive
```

The OCR layer expects `tesseract` on `PATH`. When the binary is missing,
the relevant subcommands exit 1 with an `error: tesseract binary not
found on PATH` message that Rundeck surfaces as a dependency problem
rather than a generic timeout.

## Evidence ledger

Sessions are saved under `~/.local/state/kvm-agent/sessions/<id>/` (or
under `$KVM_SESSION_ROOT` / `--session-root`). The session directory is
created with mode 0700 and every file inside it with mode 0600. The
directory contains:

- one PNG per captured observation, named `<id>.png`;
- a flushed and fsynced `events.jsonl` ledger; and
- a `summary.json` file written on clean close.

Each JSONL record carries a schema version, UTC timestamp, session /
observation / action ids, screen dimensions and SHA256, backend status,
vision-model assessment (state, visible text, confidence, rationale,
expected result), dispatch status, transport description and links to
the after-action image evidence. Typed text is redacted to
`[redacted]` plus a character count before it enters the ledger.
Screenshots and visible-text transcriptions can still contain
credentials or private information; they remain local unless explicitly
sent to the configured vision endpoint.

## Action language

Every action is validated before it can be dispatched. The validator
rejects unknown fields, non-finite numbers, out-of-range coordinates,
key type strings longer than 2048 characters, hotkeys without a
non-modifier key and any action whose kind is not listed by the active
backend. There is no shell escape, no command execution, no host
filesystem access through the action layer.

| Kind    | Fields |
|---------|--------|
| `click` | `x`, `y`, `button` (left / middle / right) |
| `move`  | `x`, `y` |
| `drag`  | `x`, `y`, `end_x`, `end_y`, `duration` (0.05..5) |
| `scroll`| `amount` (-20..20, nonzero) |
| `press` | `key` |
| `hotkey`| `keys` (1..5 names, mix of modifier and key) |
| `type`  | `text` (printable US ASCII, 1..2048 chars) |
| `wait`  | `seconds` (0..30) |

Coordinates are normalized to `0..1` over the captured viewport, so a
model never receives raw pixel counts it cannot map back to the screen.

## Vendor application setup

1. Log out, choose **Ubuntu on Xorg** from the login gear menu and log in.
2. Plug in the vendor's USB 3 host cable, the target video cable and the
   target USB cable.
3. Run `./kvm-agent launch` to start the vendor application.
4. Run `./kvm-agent doctor` and copy the vendor window's id from the
   `kvmapp_windows` field.
5. From the UI's *Select video area*, drag a rectangle over the remote
   video inside the vendor window. The viewport is then ready.
6. Connect from the UI; check *Enable remote keyboard and mouse* only
   after you have confirmed the viewport matches the target screen.
7. For absolute mouse coordinates, turn on the vendor application's
   *Absolute mouse coordinates* option and check the matching
   confirmation in the UI. Without this, the model only sees
   keyboard / wait / hotkey / press actions.

For coordinate-based mouse actions, turn on the vendor video
application's *absolute mouse coordinates* option and check the
matching confirmation in the UI (CLI: `--absolute-mouse`). Without this
option, the model only sees keyboard / wait / hotkey / press actions
because absolute coordinates cannot be guaranteed under relative mouse
mode.

If the application cannot open the USB device, verify the logged-in
user has access to its `/dev/videoN` and `/dev/hidrawN` nodes. The
`./kvm-agent setup-device-access` command requests desktop
administrator authentication to install a single narrowly-scoped udev
rule for the device's USB vendor id and product id, granting access to
the active local user via `uaccess` rather than world-writable
permissions. Replug the host cable afterwards. The helper refuses to
overwrite a differing existing rule and does not run at startup.

## Bundle layout

For a portable bundle, the layout is:

```
kvm-agent                              # the compiled binary (Go stdlib only)
kvm-agent-launcher                     # POSIX shell wrapper that execs the binary
70-kvm-agent.rules                     # optional udev rule for device access
setup-device-access                    # shell helper invoked via pkexec
ui.html                                # embedded inside the binary at build time
README.md                              # this file
vendor/KvmApp                          # vendor video-application binary
vendor/lib, plugins                    # vendor libraries and Qt plugins
```

The launcher script sets the working directory, sets `LD_LIBRARY_PATH`
for the vendor libraries, exports `QT_QPA_PLATFORM=xcb` and execs the
binary.

## Limitations

- The agent cannot introspect remote machine state directly; the model
  only sees the captured frame. Use it as a vision-driven remote-control
  agent, not as a host scripting tool.
- Target-side input forwarding cannot be verified. The transport is
  always labelled `unverified` in the JSONL ledger; the verification
  field is `screen_evidence_available; target receipt not proven`.
- `kvm-agent` does not implement a new vendor activation protocol; it
  only drives the vendor application through XTEST.
- The vendor application intercepts some combinations for its own menus
  or capture mode; review the before / after frame pair to confirm the
  intended result.
- Use a US host and target keyboard layout for reliable text entry.

## Acknowledgements

This Go port preserves the safety contracts from the prior Python
implementation but does not copy its source or depend on any external
KVM SDK.

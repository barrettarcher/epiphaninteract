// Package backends provides the capture/input backends used by the
// session manager.
package backends

import (
	"image"

	"kvm-agent/internal/actions"
)

// Backend captures frames from a video source and dispatches input actions
// to the target. Implementations must be safe to call sequentially from a
// single goroutine; the Session holds a lock that serialises calls.
type Backend interface {
	Name() string
	Capabilities() []string
	// Capture returns the captured frame along with a status dict describing
	// the backend's identity and current geometry. status is later passed to
	// ValidateContext to ensure the same context still applies.
	Capture() (image.Image, map[string]any, error)
	// ValidateContext is called immediately before an action is dispatched
	// to ensure the screen still reflects the status returned at capture.
	ValidateContext(status map[string]any) error
	// Execute dispatches the action. The receipt map describes the transport
	// used and is logged for the operator's review.
	Execute(action map[string]any) (map[string]any, error)
	Close() error
}

// capabilitySet is a small helper to keep backend capability lists sorted
// and deterministic.
type capabilitySet map[string]struct{}

func newCap(kinds ...string) capabilitySet {
	out := capabilitySet{}
	for _, k := range kinds {
		out[k] = struct{}{}
	}
	return out
}

func (c capabilitySet) has(kind string) bool {
	_, ok := c[kind]
	return ok
}

func (c capabilitySet) list() []string {
	out := make([]string, 0, len(c))
	for k := range c {
		out = append(out, k)
	}
	return out
}

// AllActionKinds returns every action kind the validator accepts, so backends
// can advertise a superset of capabilities when desired.
func AllActionKinds() []string {
	return append([]string{}, actions.AllowedActionKinds...)
}

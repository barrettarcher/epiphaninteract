package backends

import (
	"bytes"
	"image"
	"image/png"
	"testing"
)

func TestDemoCaptureProducesPNG(t *testing.T) {
	d := NewDemo()
	img, status, err := d.Capture()
	if err != nil {
		t.Fatal(err)
	}
	if status["synthetic"] != true {
		t.Errorf("expected synthetic marker, got %v", status)
	}
	if img.Bounds().Dx() < 2 || img.Bounds().Dy() < 2 {
		t.Errorf("frame too small")
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		t.Errorf("png encode failed: %v", err)
	}
	if buf.Len() < 100 {
		t.Errorf("png output looks empty: %d bytes", buf.Len())
	}
}

func TestDemoExecuteCountsActions(t *testing.T) {
	d := NewDemo()
	for i := 0; i < 3; i++ {
		_, err := d.Execute(map[string]any{"kind": "click", "x": 0.5, "y": 0.5})
		if err != nil {
			t.Fatal(err)
		}
	}
	if d.count != 3 {
		t.Errorf("expected 3 actions, got %d", d.count)
	}
}

func TestDemoCapabilities(t *testing.T) {
	d := NewDemo()
	caps := d.Capabilities()
	want := map[string]bool{"click": false, "wait": false, "type": false}
	for _, c := range caps {
		if _, ok := want[c]; ok {
			want[c] = true
		}
	}
	for k, found := range want {
		if !found {
			t.Errorf("missing capability %s", k)
		}
	}
}

func TestParseWindowID(t *testing.T) {
	cases := []struct {
		in      string
		want    uint32
		wantErr bool
	}{
		{"0x12345", 0x12345, false},
		{"12345", 12345, false},
		{"0Xabc", 0xabc, false},
		{"", 0, true},
		{"nope", 0, true},
	}
	for _, c := range cases {
		got, err := parseWindowID(c.in)
		if (err != nil) != c.wantErr {
			t.Errorf("parseWindowID(%q) err=%v, wantErr=%v", c.in, err, c.wantErr)
		}
		if !c.wantErr && got != c.want {
			t.Errorf("parseWindowID(%q) = %d, want %d", c.in, got, c.want)
		}
	}
}

func TestSanityFill(t *testing.T) {
	img := SanityFill(20, 10)
	if img.Bounds() != image.Rect(0, 0, 20, 10) {
		t.Errorf("bad bounds")
	}
}

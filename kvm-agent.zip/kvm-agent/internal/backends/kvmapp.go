package backends

import (
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"os"
	"strconv"
	"strings"
	"time"

	"kvm-agent/internal/x11"
)


// KvmAppBackend drives the vendor video-application through XTEST. It
// captures the vendor's video viewport and dispatches keyboard / mouse input
// to that window. The vendor GUI must own the target machine; this backend
// only talks to the vendor GUI itself, not directly to a remote kernel.
type KvmAppBackend struct {
	conn      *x11.Conn
	window    uint32
	viewport  [4]int16 // x, y, width, height (relative to client area)
	caps      capabilitySet
	verifyPID bool // set false only for synthetic test fixtures
	aliases   map[string]string
}

// NewKvmApp connects to the X server, locates the vendor video-application
// window matching the given window ID, and verifies that the window is owned
// by the "KvmApp" executable. absoluteMouse enables click/move/drag/scroll.
func NewKvmApp(display string, windowID string, viewport [4]int, absoluteMouse bool) (*KvmAppBackend, error) {
	conn, err := x11.Connect(display)
	if err != nil {
		return nil, err
	}
	b := &KvmAppBackend{
		conn:      conn,
		verifyPID: true,
		aliases: map[string]string{
			"enter": "Return", "esc": "Escape", "backspace": "BackSpace",
			"tab": "Tab", "space": "space", "delete": "Delete", "insert": "Insert",
			"home": "Home", "end": "End", "pageup": "Prior", "pagedown": "Next",
			"left": "Left", "right": "Right", "up": "Up", "down": "Down",
			"ctrl": "Control_L", "shift": "Shift_L", "alt": "Alt_L", "super": "Super_L",
		},
		caps: newCap("press", "hotkey", "type", "wait"),
	}
	if !conn.HasXTEST() {
		conn.Close()
		return nil, errors.New("backends: X server has no XTEST input extension")
	}
	if os.Getenv("XDG_SESSION_TYPE") == "wayland" || os.Getenv("WAYLAND_DISPLAY") != "" {
		conn.Close()
		return nil, errors.New("backends: vendor control requires an Xorg desktop session")
	}
	if viewport[0] < 0 || viewport[1] < 0 || viewport[2] < 2 || viewport[3] < 2 {
		conn.Close()
		return nil, errors.New("backends: viewport must be positive integers")
	}
	for i, v := range viewport {
		b.viewport[i] = int16(v)
	}
	wid, err := parseWindowID(windowID)
	if err != nil {
		conn.Close()
		return nil, err
	}
	b.window = wid
	if absoluteMouse {
		b.caps = capabilitySet{
			"press": {}, "hotkey": {}, "type": {}, "wait": {},
			"click": {}, "move": {}, "drag": {}, "scroll": {},
		}
	}
	if err := b.identity(); err != nil {
		conn.Close()
		return nil, err
	}
	if _, err := b.geometry(); err != nil {
		conn.Close()
		return nil, err
	}
	return b, nil
}

// NewKvmAppCalibration is a relaxed constructor used by the calibration
// flow: it lets the caller select any window regardless of executable name,
// and reports the full client area so the UI can prompt the user to drag a
// viewport rectangle over the video region.
func NewKvmAppCalibration(display string, windowID string) (*KvmAppBackend, error) {
	conn, err := x11.Connect(display)
	if err != nil {
		return nil, err
	}
	b := &KvmAppBackend{
		conn:      conn,
		verifyPID: false,
		aliases: map[string]string{
			"enter": "Return", "esc": "Escape", "backspace": "BackSpace",
			"tab": "Tab", "space": "space", "delete": "Delete", "insert": "Insert",
			"home": "Home", "end": "End", "pageup": "Prior", "pagedown": "Next",
			"left": "Left", "right": "Right", "up": "Up", "down": "Down",
			"ctrl": "Control_L", "shift": "Shift_L", "alt": "Alt_L", "super": "Super_L",
		},
		caps: newCap("wait"),
	}
	wid, err := parseWindowID(windowID)
	if err != nil {
		conn.Close()
		return nil, err
	}
	b.window = wid
	g, err := b.geometry()
	if err != nil {
		conn.Close()
		return nil, err
	}
	// For calibration we set the viewport to the full client area.
	b.viewport = [4]int16{0, 0, int16(g["window_width"].(int)), int16(g["window_height"].(int))}
	return b, nil
}

// CalibrationViewport returns the vendor-window client rectangle for the
// caller to seed the UI with. It is used after the user has selected the
// vendor window via "Check devices".
func CalibrationViewport(b *KvmAppBackend) (x, y, w, h int) {
	return int(b.viewport[0]), int(b.viewport[1]), int(b.viewport[2]), int(b.viewport[3])
}

func (b *KvmAppBackend) Name() string         { return "vendor-kvmapp-x11" }
func (b *KvmAppBackend) Capabilities() []string { return b.caps.list() }

// Capture grabs the configured rectangle from the root screen.
func (b *KvmAppBackend) Capture() (image.Image, map[string]any, error) {
	if err := b.focus(); err != nil {
		return nil, nil, err
	}
	time.Sleep(80 * time.Millisecond)
	status, err := b.geometry()
	if err != nil {
		return nil, nil, err
	}
	x := status["window_x"].(int) + int(b.viewport[0])
	y := status["window_y"].(int) + int(b.viewport[1])
	w := int(b.viewport[2])
	h := int(b.viewport[3])
	raw, err := b.conn.GetImage(b.conn.Root(), int16(x), int16(y), uint16(w), uint16(h))
	if err != nil {
		return nil, nil, err
	}
	img, err := decodeXImage(raw, w, h)
	if err != nil {
		return nil, nil, err
	}
	if again, err := b.geometry(); err != nil || !geometryEqual(again, status) {
		return nil, nil, errors.New("backends: window moved during capture; capture again")
	}
	return img, status, nil
}

// ValidateContext ensures the window is still where we last saw it.
func (b *KvmAppBackend) ValidateContext(status map[string]any) error {
	now, err := b.geometry()
	if err != nil {
		return err
	}
	if !geometryEqual(now, status) {
		return errors.New("backends: vendor window geometry changed since capture; re-inspect")
	}
	if err := b.focus(); err != nil {
		return err
	}
	return nil
}

// Execute dispatches an action via XTEST.
func (b *KvmAppBackend) Execute(action map[string]any) (map[string]any, error) {
	kind, _ := action["kind"].(string)
	if !b.caps.has(kind) {
		return nil, fmt.Errorf("backends: capability %q not enabled", kind)
	}
	switch kind {
	case "wait":
		time.Sleep(time.Duration(action["seconds"].(float64) * float64(time.Second)))
		return map[string]any{"transport": "local delay"}, nil
	case "press":
		code, err := b.keycode(action["key"].(string))
		if err != nil {
			return nil, err
		}
		b.chord([]byte{code})
		return receipt("X11 XTEST to vendor GUI"), nil
	case "hotkey":
		ks := action["keys"].([]string)
		codes := make([]byte, 0, len(ks))
		for _, k := range ks {
			c, err := b.keycode(k)
			if err != nil {
				return nil, err
			}
			codes = append(codes, c)
		}
		b.chord(codes)
		return receipt("X11 XTEST to vendor GUI"), nil
	case "type":
		text := action["text"].(string)
		for _, ch := range text {
			b.typeChar(byte(ch))
		}
		return receipt("X11 XTEST to vendor GUI"), nil
	case "click", "move", "drag":
		x := action["x"].(float64)
		y := action["y"].(float64)
		if err := b.moveTo(x, y); err != nil {
			return nil, err
		}
		if kind == "click" {
			button := 1
			switch action["button"].(string) {
			case "middle":
				button = 2
			case "right":
				button = 3
			}
			if err := b.click(button); err != nil {
				return nil, err
			}
		}
		if kind == "drag" {
			if err := b.dragTo(action["end_x"].(float64), action["end_y"].(float64), action["duration"].(float64)); err != nil {
				return nil, err
			}
		}
		return receipt("X11 XTEST to vendor GUI"), nil
	case "scroll":
		b.moveTo(0.5, 0.5)
		amount := action["amount"].(int)
		for i := 0; i < abs(amount); i++ {
			btn := 4
			if amount < 0 {
				btn = 5
			}
			if err := b.click(btn); err != nil {
				return nil, err
			}
		}
		return receipt("X11 XTEST to vendor GUI"), nil
	}
	return nil, fmt.Errorf("backends: unhandled action kind %q", kind)
}

func (b *KvmAppBackend) Close() error {
	if b.conn != nil {
		return b.conn.Close()
	}
	return nil
}

// identity checks that the window's owning executable is the vendor binary.
func (b *KvmAppBackend) identity() error {
	if !b.verifyPID {
		return nil
	}
	pidAtom, err := b.conn.InternAtom("_NET_WM_PID")
	if err != nil {
		return err
	}
	raw, err := b.conn.GetProperty(b.window, pidAtom, x11.AtomAnyProperty, 1, 0)
	if err != nil {
		return fmt.Errorf("backends: cannot read window PID: %w", err)
	}
	if len(raw) < 4 {
		return errors.New("backends: cannot read window PID")
	}
	pid := uint32(raw[0]) | uint32(raw[1])<<8 | uint32(raw[2])<<16 | uint32(raw[3])<<24
	exe, err := os.Readlink(fmt.Sprintf("/proc/%d/exe", pid))
	if err != nil {
		return fmt.Errorf("backends: cannot resolve /proc/%d/exe: %w", pid, err)
	}
	base := exe
	if i := strings.LastIndex(exe, "/"); i >= 0 {
		base = exe[i+1:]
	}
	if base != "KvmApp" {
		return fmt.Errorf("backends: selected window is owned by %q, expected KvmApp", base)
	}
	return nil
}

// geometry returns the current vendor window geometry plus screen bounds.
func (b *KvmAppBackend) geometry() (map[string]any, error) {
	if err := b.identity(); err != nil {
		return nil, err
	}
	g, err := b.conn.GetGeometry(b.window)
	if err != nil {
		return nil, err
	}
	rootG, err := b.conn.GetGeometry(b.conn.Root())
	if err != nil {
		return nil, err
	}
	_, x0, y0, err := b.conn.TranslateCoordinates(b.window, b.conn.Root(), 0, 0)
	if err != nil {
		return nil, err
	}
	w, h := int(g.Width), int(g.Height)
	_ = w; _ = h
	if int(b.viewport[0])+int(b.viewport[2]) > int(g.Width) || int(b.viewport[1])+int(b.viewport[3]) > int(g.Height) {
		return nil, errors.New("backends: viewport lies outside vendor window client area")
	}
	if int(x0)+int(b.viewport[0]) < 0 || int(y0)+int(b.viewport[1]) < 0 ||
		int(x0)+int(b.viewport[0])+int(b.viewport[2]) > int(rootG.Width) ||
		int(y0)+int(b.viewport[1])+int(b.viewport[3]) > int(rootG.Height) {
		return nil, errors.New("backends: viewport is partially outside the screen")
	}
	return map[string]any{
		"window_id":     b.window,
		"window_x":      int(x0),
		"window_y":      int(y0),
		"window_width":  w,
		"window_height": h,
		"viewport":      []int{int(b.viewport[0]), int(b.viewport[1]), int(b.viewport[2]), int(b.viewport[3])},
		"signal_active": "unknown; inspect image",
	}, nil
}

func (b *KvmAppBackend) focus() error {
	if err := b.conn.RaiseAbove(b.window); err != nil {
		return err
	}
	if err := b.conn.SetInputFocus(b.window); err != nil {
		return err
	}
	cur, err := b.conn.GetInputFocus()
	if err != nil {
		return err
	}
	if cur != b.window {
		return errors.New("backends: vendor window failed to receive focus")
	}
	return nil
}

func (b *KvmAppBackend) keycode(name string) (byte, error) {
	alias, ok := b.aliases[strings.ToLower(name)]
	if !ok {
		alias = name
	}
	if strings.HasPrefix(alias, "F") && len(alias) > 1 {
		// "F1" .. "F12" already canonical.
	} else if len(alias) == 1 {
		// ASCII printable: pass through.
	} else if strings.HasPrefix(alias, "XK_") {
		alias = strings.TrimPrefix(alias, "XK_")
	}
	keysym, ok := x11.ResolveKeysym(alias)
	if !ok {
		return 0, fmt.Errorf("backends: unknown key %q", name)
	}
	code, _, ok := b.conn.LookupKeycode(keysym)
	if !ok {
		return 0, fmt.Errorf("backends: key %q not in server keyboard layout", name)
	}
	return code, nil
}

func (b *KvmAppBackend) chord(codes []byte) {
	pressed := make([]byte, 0, len(codes))
	for _, c := range codes {
		_ = b.conn.FakeKeyPress(c)
		pressed = append(pressed, c)
	}
	time.Sleep(25 * time.Millisecond)
	for i := len(pressed) - 1; i >= 0; i-- {
		_ = b.conn.FakeKeyRelease(pressed[i])
	}
}

func (b *KvmAppBackend) typeChar(ch byte) {
	sym := uint32(ch)
	code, _, ok := b.conn.LookupKeycode(sym)
	if ok {
		b.chord([]byte{code})
		return
	}
	// Try shifted variant: e.g. 'A' -> shift + 'a'.
	shiftSym, ok := x11.ResolveKeysym("shift")
	if !ok {
		panic("backends: shift keysym missing from table")
	}
	shiftCode, _, _ := b.conn.LookupKeycode(shiftSym)
	lowerSym, ok := x11.ResolveKeysym(strings.ToLower(string(ch)))
	if ok && shiftCode != 0 {
		if lowerCode, _, found := b.conn.LookupKeycode(lowerSym); found {
			b.chord([]byte{shiftCode, lowerCode})
			return
		}
	}
	// No server keycode available: raise an error before any partial typing.
	panic(fmt.Sprintf("backends: X11 keyboard layout cannot type %q", string(ch)))
}

func (b *KvmAppBackend) moveTo(xnorm, ynorm float64) error {
	status, err := b.geometry()
	if err != nil {
		return err
	}
	px := status["window_x"].(int) + int(b.viewport[0]) + int(xnorm*float64(int(b.viewport[2])-1))
	py := status["window_y"].(int) + int(b.viewport[1]) + int(ynorm*float64(int(b.viewport[3])-1))
	return b.conn.WarpPointer(0, b.conn.Root(), int16(px), int16(py))
}

func (b *KvmAppBackend) click(button int) error {
	if err := b.conn.FakeButtonPress(byte(button)); err != nil {
		return err
	}
	time.Sleep(50 * time.Millisecond)
	return b.conn.FakeButtonRelease(byte(button))
}

func (b *KvmAppBackend) dragTo(xend, yend, duration float64) error {
	if err := b.conn.FakeButtonPress(x11.ButtonLeft); err != nil {
		return err
	}
	defer b.conn.FakeButtonRelease(x11.ButtonLeft)
	step := duration / 20
	for i := 1; i <= 20; i++ {
		t := float64(i) / 20
		if err := b.moveTo(lerpCurrent(xend, t), lerpCurrent(yend, t)); err != nil {
			return err
		}
		time.Sleep(time.Duration(step * float64(time.Second)))
	}
	return nil
}

// --- helpers --------------------------------------------------------------

func receipt(transport string) map[string]any {
	return map[string]any{"transport": transport, "target_receipt": "unverified"}
}

func geometryEqual(a, b map[string]any) bool {
	for _, k := range []string{"window_id", "window_x", "window_y", "window_width", "window_height"} {
		if a[k] != b[k] {
			return false
		}
	}
	return true
}

func parseWindowID(s string) (uint32, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, errors.New("backends: window id is required")
	}
	n, err := strconv.ParseUint(s, 0, 32)
	if err != nil {
		return 0, fmt.Errorf("backends: invalid window id %q: %w", s, err)
	}
	return uint32(n), nil
}

func abs(i int) int {
	if i < 0 {
		return -i
	}
	return i
}

func lerpCurrent(target, t float64) float64 {
	return target * t
}

// decodeXImage converts raw BGRA / BGRX pixels (X11 default visual) into an
// image.NRGBA suitable for PNG encoding.
func decodeXImage(raw []byte, w, h int) (image.Image, error) {
	if len(raw) < w*h*4 {
		return nil, fmt.Errorf("backends: short capture buffer %d bytes for %dx%d", len(raw), w, h)
	}
	img := image.NewNRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			off := (y*w + x) * 4
			img.Pix[off+0] = raw[off+2] // R
			img.Pix[off+1] = raw[off+1] // G
			img.Pix[off+2] = raw[off+0] // B
			img.Pix[off+3] = 0xff
		}
	}
	return img, nil
}

// FindVendorWindows enumerates top-level X11 windows and returns those
// whose owning executable is the vendor binary.
func FindVendorWindows(display string) ([]WindowInfo, error) {
	conn, err := x11.Connect(display)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	pidAtom, err := conn.InternAtom("_NET_WM_PID")
	if err != nil {
		return nil, err
	}
	listAtom, err := conn.InternAtom("_NET_CLIENT_LIST")
	if err != nil {
		return nil, err
	}
	nameAtom, err := conn.InternAtom("_NET_WM_NAME")
	if err != nil {
		return nil, err
	}
	raw, err := conn.GetProperty(conn.Root(), listAtom, x11.AtomAnyProperty, 4096, 0)
	if err != nil {
		return nil, err
	}
	var ids []uint32
	for i := 0; i+4 <= len(raw); i += 4 {
		ids = append(ids, uint32(raw[i])|uint32(raw[i+1])<<8|uint32(raw[i+2])<<16|uint32(raw[i+3])<<24)
	}
	var result []WindowInfo
	for _, id := range ids {
		pidRaw, err := conn.GetProperty(id, pidAtom, x11.AtomAnyProperty, 1, 0)
		if err != nil || len(pidRaw) < 4 {
			continue
		}
		pid := uint32(pidRaw[0]) | uint32(pidRaw[1])<<8 | uint32(pidRaw[2])<<16 | uint32(pidRaw[3])<<24
		exe, err := os.Readlink(fmt.Sprintf("/proc/%d/exe", pid))
		if err != nil {
			continue
		}
		base := exe
		if i := strings.LastIndex(exe, "/"); i >= 0 {
			base = exe[i+1:]
		}
		if base != "KvmApp" {
			continue
		}
		g, err := conn.GetGeometry(id)
		if err != nil {
			continue
		}
		title := ""
		nameRaw, _ := conn.GetProperty(id, nameAtom, x11.AtomAnyProperty, 256, 0)
		title = string(nameRaw)
		result = append(result, WindowInfo{
			WindowID:    fmt.Sprintf("0x%x", id),
			Title:       title,
			ClientWidth: int(g.Width),
			ClientHeight: int(g.Height),
		})
	}
	return result, nil
}

// WindowInfo describes a candidate vendor window.
type WindowInfo struct {
	WindowID     string `json:"window_id"`
	Title        string `json:"title"`
	ClientWidth  int    `json:"client_size_width"`
	ClientHeight int    `json:"client_size_height"`
}

// VideoDevices lists /dev/videoN nodes. The KvmAppBackend uses V4L2 through
// a direct UVC capture if the operator chose the "kvmapp" backend; this
// helper is provided for the doctor command.
func VideoDevices() []map[string]string {
	out := []map[string]string{}
	entries, err := os.ReadDir("/sys/class/video4linux")
	if err != nil {
		return out
	}
	for _, e := range entries {
		node := "/dev/" + e.Name()
		name, _ := os.ReadFile("/sys/class/video4linux/" + e.Name() + "/name")
		vendor, _ := os.ReadFile("/sys/class/video4linux/" + e.Name() + "/device/idVendor")
		out = append(out, map[string]string{
			"node":   node,
			"name":   strings.TrimSpace(string(name)),
			"vendor": strings.TrimSpace(string(vendor)),
		})
	}
	return out
}

// SanityFill draws a solid colour rectangle. Used by tests to verify that
// the capture region is wired correctly.
func SanityFill(w, h int) image.Image {
	img := image.NewNRGBA(image.Rect(0, 0, w, h))
	draw.Draw(img, img.Bounds(), &image.Uniform{C: color.RGBA{R: 0xff, A: 0xff}}, image.Point{}, draw.Src)
	return img
}

package actions

import (
	"strings"
	"testing"
)

func TestInvalidActions(t *testing.T) {
	cases := []map[string]any{
		{"kind": "shell", "command": "x"},
		{"kind": "click", "x": -1, "y": 0.5},
		{"kind": "click", "x": "0.5", "y": 0.5},
		{"kind": "click", "x": true, "y": 0.5},
		{"kind": "type", "text": "é"},
		{"kind": "type", "text": "a\nPRESS enter"},
		{"kind": "wait", "seconds": 60},
		{"kind": "press", "key": "nope"},
		{"kind": "scroll", "amount": 0},
		{"kind": "scroll", "amount": 21},
		{"kind": "hotkey", "keys": []any{"ctrl"}},
		{"kind": "hotkey", "keys": []any{"ctrl", "ctrl"}},
		{"kind": "click", "x": 0.5, "y": 0.5, "shell": "x"},
	}
	for _, c := range cases {
		func() {
			defer func() {
				if r := recover(); r == nil {
					t.Errorf("expected panic on %v", c)
				}
			}()
			Validate(c)
		}()
	}
}

func TestValidBoundaries(t *testing.T) {
	out := Validate(map[string]any{"kind": "click", "x": 0, "y": 1})
	if out["button"] != "left" {
		t.Errorf("default button should be left, got %v", out["button"])
	}
	Validate(map[string]any{"kind": "type", "text": "AbC !@#$%^&*()_+{}|:\"<>?"})
	Validate(map[string]any{"kind": "hotkey", "keys": []any{"ctrl", "alt", "delete"}})
	Validate(map[string]any{"kind": "drag", "x": 0, "y": 0, "end_x": 1, "end_y": 1, "duration": 0.1})
}

func TestLoggedActionRedactsType(t *testing.T) {
	logged := LoggedAction(map[string]any{"kind": "type", "text": "PrivatePassword123!"})
	if logged["text"] != "[redacted]" {
		t.Errorf("typed text should be redacted, got %v", logged["text"])
	}
	if logged["characters"].(int) != len("PrivatePassword123!") {
		t.Errorf("character count should be preserved")
	}
}

func TestParseJSON(t *testing.T) {
	if _, err := ParseJSON([]byte(`{"kind":"click","x":0.1,"y":0.2}`)); err != nil {
		t.Errorf("unexpected error: %v", err)
	}
	if _, err := ParseJSON([]byte(`["nope"]`)); err == nil {
		t.Errorf("expected error for array payload")
	}
	if _, err := ParseJSON([]byte(`not json`)); err == nil {
		t.Errorf("expected error for invalid JSON")
	}
}

func TestDragDurationDefault(t *testing.T) {
	out := Validate(map[string]any{"kind": "drag", "x": 0, "y": 0, "end_x": 1, "end_y": 1})
	if out["duration"].(float64) != 0.5 {
		t.Errorf("default drag duration should be 0.5, got %v", out["duration"])
	}
}

func TestHotkeyDeduplication(t *testing.T) {
	if func() (panicked bool) {
		defer func() {
			if r := recover(); r != nil {
				panicked = true
			}
		}()
		Validate(map[string]any{"kind": "hotkey", "keys": []any{"ctrl", "a", "ctrl"}})
		return false
	}() == false {
		t.Errorf("duplicate modifier should panic")
	}
}

func TestAllowedActionKindsSorted(t *testing.T) {
	kinds := AllowedActionKinds
	if len(kinds) == 0 {
		t.Fatal("kinds list should not be empty")
	}
	for i := 1; i < len(kinds); i++ {
		if kinds[i-1] > kinds[i] {
			t.Errorf("kinds not sorted: %v", kinds)
		}
	}
	if !strings.Contains(strings.Join(kinds, ","), "click") {
		t.Errorf("expected click in allowed kinds, got %v", kinds)
	}
}

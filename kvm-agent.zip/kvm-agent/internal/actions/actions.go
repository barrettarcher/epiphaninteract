// Package actions defines the strict, finite action vocabulary shared by
// the CLI, the HTTP server and the local UI. The set of accepted kinds,
// their fields and the value-range checks are enforced uniformly so that
// the vision model, the UI and the CLI all speak the same language.
package actions

import (
	"encoding/json"
	"math"
	"sort"
	"strings"
)

// Key is a recognized key identifier (logical XK name or ASCII printable).
var Keys = func() map[string]struct{} {
	set := map[string]struct{}{
		"enter": {}, "esc": {}, "backspace": {}, "tab": {}, "space": {},
		"delete": {}, "insert": {}, "home": {}, "end": {},
		"pageup": {}, "pagedown": {}, "left": {}, "right": {}, "up": {}, "down": {},
	}
	for _, c := range "abcdefghijklmnopqrstuvwxyz0123456789" {
		set[string(c)] = struct{}{}
	}
	for i := 1; i <= 12; i++ {
		set["f"+itoa(i)] = struct{}{}
	}
	return set
}()

// Mods are recognized modifier identifiers.
var Mods = map[string]struct{}{
	"ctrl": {}, "shift": {}, "alt": {}, "super": {},
}

// fields per kind.
var fieldsByKind = map[string]map[string]struct{}{
	"click":  {"x": {}, "y": {}, "button": {}},
	"move":   {"x": {}, "y": {}},
	"drag":   {"x": {}, "y": {}, "end_x": {}, "end_y": {}, "duration": {}},
	"scroll": {"amount": {}},
	"press":  {"key": {}},
	"hotkey": {"keys": {}},
	"type":   {"text": {}},
	"wait":   {"seconds": {}},
}

// AllowedActionKinds lists the permitted action kinds in a deterministic order.
var AllowedActionKinds = func() []string {
	out := make([]string, 0, len(fieldsByKind))
	for k := range fieldsByKind {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}()

// Number checks finite value within a range.
func Number(value float64, low, high float64, name string) float64 {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		panic("actions: " + name + " must be finite")
	}
	if value < low || value > high {
		panic("actions: " + name + " out of range")
	}
	return value
}

// Validate enforces shape and value-range constraints for an action. It
// returns a normalised copy (filling defaults) or panics with a descriptive
// ValueError-style string. Action is taken as a generic map so the validator
// can be reused from the CLI/JSON path and the Go-native backend calls.
func Validate(action map[string]any) map[string]any {
	kind, _ := action["kind"].(string)
	fields, ok := fieldsByKind[kind]
	if !ok {
		panic("actions: unknown kind " + kind)
	}
	// Reject unknown fields.
	for k := range action {
		if k == "kind" {
			continue
		}
		if _, ok := fields[k]; !ok {
			panic("actions: unexpected field " + k)
		}
	}
	out := map[string]any{"kind": kind}
	for k, v := range action {
		if k != "kind" {
			out[k] = v
		}
	}
	switch kind {
	case "click", "move":
		out["x"] = Number(toFloat(out["x"]), 0, 1, "x")
		out["y"] = Number(toFloat(out["y"]), 0, 1, "y")
		if kind == "click" {
			button, _ := out["button"].(string)
			if button == "" {
				button = "left"
			}
			if button != "left" && button != "middle" && button != "right" {
				panic("actions: invalid mouse button")
			}
			out["button"] = button
		}
	case "drag":
		out["x"] = Number(toFloat(out["x"]), 0, 1, "x")
		out["y"] = Number(toFloat(out["y"]), 0, 1, "y")
		out["end_x"] = Number(toFloat(out["end_x"]), 0, 1, "end_x")
		out["end_y"] = Number(toFloat(out["end_y"]), 0, 1, "end_y")
		d, ok := out["duration"].(float64)
		if !ok {
			d = 0.5
		}
		out["duration"] = Number(d, 0.05, 5, "duration")
	case "scroll":
		amt, ok := toInt(out["amount"])
		if !ok || amt == 0 || amt < -20 || amt > 20 {
			panic("actions: scroll amount must be a nonzero integer from -20 to 20")
		}
		out["amount"] = amt
	case "press":
		key, _ := out["key"].(string)
		if _, ok := Keys[strings.ToLower(key)]; !ok {
			panic("actions: unsupported key")
		}
		out["key"] = strings.ToLower(key)
	case "hotkey":
		keysAny, ok := out["keys"].([]any)
		if !ok {
			panic("actions: hotkey keys must be a list")
		}
		if len(keysAny) < 1 || len(keysAny) > 5 {
			panic("actions: hotkey must have 1..5 keys")
		}
		seen := map[string]struct{}{}
		hasKey := false
		keys := make([]string, 0, len(keysAny))
		for _, k := range keysAny {
			s, ok := k.(string)
			if !ok {
				panic("actions: hotkey keys must be strings")
			}
			s = strings.ToLower(s)
			if _, ok := Keys[s]; !ok {
				if _, ok := Mods[s]; !ok {
					panic("actions: invalid hotkey key " + s)
				}
			} else {
				hasKey = true
			}
			if _, dup := seen[s]; dup {
				panic("actions: duplicate hotkey key " + s)
			}
			seen[s] = struct{}{}
			keys = append(keys, s)
		}
		if !hasKey {
			panic("actions: hotkey must include a non-modifier key")
		}
		out["keys"] = keys
	case "type":
		text, _ := out["text"].(string)
		if len(text) < 1 || len(text) > 2048 {
			panic("actions: type supports 1..2048 characters")
		}
		for i := 0; i < len(text); i++ {
			c := text[i]
			if c < 0x20 || c > 0x7e {
				panic("actions: type accepts US ASCII printable only; use press for Enter/Tab")
			}
		}
		out["text"] = text
	case "wait":
		out["seconds"] = Number(toFloat(out["seconds"]), 0, 30, "seconds")
	}
	return out
}

// LoggedAction returns a copy of the action safe to persist in the JSONL
// evidence ledger: typed text is redacted to a marker and a character count.
func LoggedAction(action map[string]any) map[string]any {
	if action["kind"] == "type" {
		text, _ := action["text"].(string)
		return map[string]any{"kind": "type", "text": "[redacted]", "characters": len(text)}
	}
	out := make(map[string]any, len(action))
	for k, v := range action {
		out[k] = v
	}
	return out
}

// ParseJSON is a convenience wrapper used by HTTP handlers.
func ParseJSON(raw []byte) (map[string]any, error) {
	var v any
	if err := json.Unmarshal(raw, &v); err != nil {
		return nil, err
	}
	m, ok := v.(map[string]any)
	if !ok {
		return nil, errActionObject
	}
	return m, nil
}

var errActionObject = stringError("actions: payload must be a JSON object")

type stringError string

func (s stringError) Error() string { return string(s) }

// --- helpers --------------------------------------------------------------

func toFloat(v any) float64 {
	switch n := v.(type) {
	case float64:
		return n
	case float32:
		return float64(n)
	case int:
		return float64(n)
	case int64:
		return float64(n)
	}
	panic("actions: expected number")
}

func toInt(v any) (int, bool) {
	switch n := v.(type) {
	case int:
		return n, true
	case int64:
		return int(n), true
	case float64:
		if math.IsNaN(n) || math.IsInf(n, 0) || n != math.Trunc(n) {
			return 0, false
		}
		return int(n), true
	}
	return 0, false
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	neg := i < 0
	if neg {
		i = -i
	}
	digits := []byte{}
	for i > 0 {
		digits = append([]byte{byte('0' + i%10)}, digits...)
		i /= 10
	}
	if neg {
		digits = append([]byte{'-'}, digits...)
	}
	return string(digits)
}

package pdu

import (
	"strings"
	"testing"
)

func TestRestOnURL(t *testing.T) {
	c := &Client{Host: "192.168.1.50", User: "admin", Pass: "x", Outlet: 3}
	req, err := c.newRequest("GET", "/restapi/relay/outlets/3/state", "value=1")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(req.URL.String(), "/restapi/relay/outlets/3/state") {
		t.Errorf("unexpected URL: %s", req.URL)
	}
	if !strings.Contains(req.URL.RawQuery, "value=1") {
		t.Errorf("missing value query: %q", req.URL.RawQuery)
	}
	u, p, ok := req.BasicAuth()
	if !ok || u != "admin" || p != "x" {
		t.Errorf("expected basic auth admin:x, got %s:%s ok=%v", u, p, ok)
	}
}

func TestLegacyTogglePath(t *testing.T) {
	c := &Client{Host: "192.168.1.50", Outlet: 7, Style: StyleLegacy}
	req, err := c.newRequest("GET", "/7On", "")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasSuffix(req.URL.Path, "/7On") {
		t.Errorf("unexpected legacy path: %s", req.URL.Path)
	}
}

func TestMissingHost(t *testing.T) {
	c := &Client{Outlet: 1}
	if _, err := c.newRequest("GET", "/x", ""); err == nil {
		t.Errorf("expected error when host is empty")
	}
	if err := c.On(); err == nil {
		t.Errorf("On() should fail when host is empty")
	}
}

func TestOnRestBuildsValueOne(t *testing.T) {
	c := &Client{Host: "h", Outlet: 2}
	c.Style = StyleREST
	req, err := c.newRequest("GET", "/restapi/relay/outlets/2/state", "value=1")
	if err != nil {
		t.Fatal(err)
	}
	if req.URL.RawQuery != "value=1" {
		t.Errorf("expected value=1, got %q", req.URL.RawQuery)
	}
}

func TestOnLegacyBuildsSevenOff(t *testing.T) {
	c := &Client{Host: "h", Outlet: 7, Style: StyleLegacy}
	req, err := c.newRequest("GET", "/7Off", "")
	if err != nil {
		t.Fatal(err)
	}
	if req.URL.Path != "/7Off" {
		t.Errorf("expected /7Off, got %s", req.URL.Path)
	}
}

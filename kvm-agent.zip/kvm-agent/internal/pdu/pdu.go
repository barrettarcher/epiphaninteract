// Package pdu is a small HTTP client for network-controlled power
// switches. The implementation targets the Digital Loggers Inc Web Power
// Switch REST API ("/restapi/relay/outlets/N/state;value=0|1") and the
// older URL-only command style ("GET /<n>On" with embedded basic
// auth). Both styles are supported so the bench can use whichever
// firmware generation is installed.
//
// The package returns descriptive errors when the PDU is unreachable,
// authentication fails or the outlet reports an error state; Rundeck
// jobs surface those messages as the harness's failure reason.
package pdu

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// Style selects which DLI command path to use.
type Style string

const (
	// StyleREST uses the modern REST API (/restapi/relay/outlets/<n>/state).
	StyleREST Style = "rest"
	// StyleLegacy uses the older URL-based commands (/<n>On, /<n>Off).
	StyleLegacy Style = "legacy"
)

// Client talks to one DLI Web Power Switch.
type Client struct {
	Host    string
	User    string
	Pass    string
	Outlet  int
	Style   Style
	Timeout time.Duration
}

// State is the parsed state of a single outlet.
type State string

const (
	StateOn  State = "On"
	StateOff State = "Off"
)

// ErrUnreachable is returned when the PDU host cannot be reached at all.
var ErrUnreachable = errors.New("pdu: unreachable")

// HTTPError reports a non-2xx response from the PDU.
type HTTPError struct {
	Status int
	Body   string
}

func (e *HTTPError) Error() string { return fmt.Sprintf("pdu: HTTP %d: %s", e.Status, e.Body) }

// On powers the outlet on.
func (c *Client) On() error {
	switch c.Style {
	case StyleLegacy:
		return c.legacyToggle(true)
	}
	return c.restSet(1)
}

// Off powers the outlet off.
func (c *Client) Off() error {
	switch c.Style {
	case StyleLegacy:
		return c.legacyToggle(false)
	}
	return c.restSet(0)
}

// Status returns the parsed outlet state. For StyleLegacy the response
// body is parsed heuristically (the legacy endpoint returns "OK" for a
// state query and the human-readable page otherwise).
func (c *Client) Status() (State, error) {
	switch c.Style {
	case StyleLegacy:
		// Legacy firmware doesn't expose a status endpoint; do a no-op
		// toggle query and report "unknown".
		return "", errors.New("pdu: legacy style does not expose outlet status")
	}
	req, err := c.newRequest(http.MethodGet, fmt.Sprintf("/restapi/relay/outlets/%d/state", c.Outlet), "")
	if err != nil {
		return "", err
	}
	body, err := c.do(req)
	if err != nil {
		return "", err
	}
	switch strings.ToLower(strings.TrimSpace(body)) {
	case "on", "1":
		return StateOn, nil
	case "off", "0":
		return StateOff, nil
	}
	return State(strings.TrimSpace(body)), nil
}

// --- internal helpers -----------------------------------------------------

func (c *Client) restSet(value int) error {
	path := fmt.Sprintf("/restapi/relay/outlets/%d/state", c.Outlet)
	req, err := c.newRequest(http.MethodGet, path, fmt.Sprintf("value=%d", value))
	if err != nil {
		return err
	}
	_, err = c.do(req)
	return err
}

func (c *Client) legacyToggle(on bool) error {
	// Legacy DLI endpoint form: GET /<outlet>On or /<outlet>Off.
	path := fmt.Sprintf("/%d%s", c.Outlet, onToggle(on))
	req, err := c.newRequest(http.MethodGet, path, "")
	if err != nil {
		return err
	}
	_, err = c.do(req)
	return err
}

func (c *Client) newRequest(method, path, rawQuery string) (*http.Request, error) {
	if c.Host == "" {
		return nil, fmt.Errorf("pdu: host is required")
	}
	u := &url.URL{
		Scheme:   "http",
		Host:     c.Host,
		Path:     path,
		RawQuery: rawQuery,
	}
	req, err := http.NewRequest(method, u.String(), nil)
	if err != nil {
		return nil, err
	}
	if c.User != "" {
		req.SetBasicAuth(c.User, c.Pass)
	}
	return req, nil
}

func (c *Client) do(req *http.Request) (string, error) {
	timeout := c.Timeout
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	httpClient := &http.Client{Timeout: timeout}
	resp, err := httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("%w: %v", ErrUnreachable, err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
	if resp.StatusCode/100 != 2 {
		return "", &HTTPError{Status: resp.StatusCode, Body: strings.TrimSpace(string(body))}
	}
	return string(body), nil
}

func onToggle(on bool) string {
	if on {
		return "On"
	}
	return "Off"
}

// Package session coordinates capture, vision interpretation, action
// dispatch and durable evidence logging. Each session writes a flushed
// JSONL ledger plus a final summary into a 0700 directory.
package session

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	"image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"sync"
	"time"

	"kvm-agent/internal/actions"
	"kvm-agent/internal/backends"
	"kvm-agent/internal/vision"
)

const (
	defaultMaxFrameAge = 120 * time.Second
	schemaVersion      = 1
)

// Session is the per-task coordinator.
type Session struct {
	mu              sync.Mutex
	backend         backends.Backend
	vision          *vision.Client
	enableInput     bool
	minConfidence   float64
	maxFrameAge     time.Duration

	id        string
	root      string
	directory string
	log       *os.File

	events             []map[string]any
	latest             *observation
	lastAssessment     map[string]any
	lastActionResult   map[string]any
	lastInterpretation string
	pending            *pendingProposal
	closed             bool
}

type observation struct {
	ID        string
	Path      string
	Width     int
	Height    int
	SHA256    string
	Timestamp string
	Status    map[string]any
}

type pendingProposal struct {
	ObservationID  string
	Action         map[string]any
	Reason         string
	ExpectedResult string
}

// Options controls session creation.
type Options struct {
	Root          string
	Vision        *vision.Client
	EnableInput   bool
	MinConfidence float64
	MaxFrameAge   time.Duration
}

// New constructs a Session backed by the supplied backend.
func New(b backends.Backend, o Options) (*Session, error) {
	if o.Root == "" {
		o.Root = os.Getenv("KVM_SESSION_ROOT")
	}
	if o.Root == "" {
		o.Root = filepath.Join(os.Getenv("HOME"), ".local/state/kvm-agent/sessions")
	}
	if o.MinConfidence <= 0 {
		o.MinConfidence = 0.8
	}
	if o.MaxFrameAge <= 0 {
		o.MaxFrameAge = defaultMaxFrameAge
	}
	if math.IsNaN(o.MinConfidence) || math.IsInf(o.MinConfidence, 0) || o.MinConfidence < 0 || o.MinConfidence > 1 {
		return nil, fmt.Errorf("session: min_confidence out of range")
	}
	id, err := newID()
	if err != nil {
		return nil, err
	}
	dir := filepath.Join(o.Root, id)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	log, err := os.OpenFile(filepath.Join(dir, "events.jsonl"), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return nil, err
	}
	s := &Session{
		backend:       b,
		vision:        o.Vision,
		enableInput:   o.EnableInput,
		minConfidence: o.MinConfidence,
		maxFrameAge:   o.MaxFrameAge,
		root:          o.Root,
		id:            id,
		directory:     dir,
		log:           log,
	}
	s.event("session_started", map[string]any{
		"backend":        b.Name(),
		"input_enabled":  o.EnableInput,
		"capabilities":   b.Capabilities(),
		"min_confidence": o.MinConfidence,
	})
	return s, nil
}

// ID returns the session id.
func (s *Session) ID() string { return s.id }

// Directory returns the on-disk evidence directory.
func (s *Session) Directory() string { return s.directory }

// Backend returns the underlying backend (read-only access; use carefully).
func (s *Session) Backend() backends.Backend { return s.backend }

// Capture grabs a frame and persists it.
func (s *Session) Capture() (map[string]any, error) {
	s.mu.Lock()
	s.pending = nil
	s.latest = nil
	s.mu.Unlock()
	frame, status, err := s.backend.Capture()
	if err != nil {
		s.event("capture_failed", map[string]any{"error_type": fmt.Sprintf("%T", err)})
		return nil, err
	}
	if frame.Bounds().Dx() < 2 || frame.Bounds().Dy() < 2 {
		return nil, fmt.Errorf("session: invalid captured frame")
	}
	id, err := randomID()
	if err != nil {
		return nil, err
	}
	path := filepath.Join(s.directory, id+".png")
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return nil, err
	}
	if err := png.Encode(f, frame); err != nil {
		f.Close()
		return nil, err
	}
	f.Close()
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	sum := sha256.Sum256(data)
	obs := &observation{
		ID:        id,
		Path:      path,
		Width:     frame.Bounds().Dx(),
		Height:    frame.Bounds().Dy(),
		SHA256:    hex.EncodeToString(sum[:]),
		Timestamp: utcNow(),
		Status:    status,
	}
	s.mu.Lock()
	s.latest = obs
	s.mu.Unlock()
	s.event("observation", map[string]any{
		"id":        obs.ID,
		"path":      obs.Path,
		"width":     obs.Width,
		"height":    obs.Height,
		"sha256":    obs.SHA256,
		"timestamp": obs.Timestamp,
		"status":    status,
	})
	return map[string]any{
		"id":        obs.ID,
		"path":      obs.Path,
		"width":     obs.Width,
		"height":    obs.Height,
		"sha256":    obs.SHA256,
		"timestamp": obs.Timestamp,
		"status":    status,
	}, nil
}

// Observe captures a frame and asks the vision model to interpret it.
func (s *Session) Observe(goal string, previous map[string]any) (map[string]any, error) {
	obs, err := s.Capture()
	if err != nil {
		return nil, err
	}
	if s.vision == nil {
		return map[string]any{"observation": obs, "assessment": nil, "pending": nil}, nil
	}
	available := s.backend.Capabilities()
	previousArg := previous
	if previousArg == nil {
		s.mu.Lock()
		previousArg = s.lastActionResult
		s.mu.Unlock()
	}
	assessment, err := s.vision.Assess(obs["path"].(string), goal, available, previousArg)
	if err != nil {
		s.event("interpretation_failed", map[string]any{
			"observation_id": obs["id"],
			"error_type":     fmt.Sprintf("%T", err),
		})
		return nil, err
	}
	if assessment.NextAction != nil {
		for _, kind := range available {
			if kind == assessment.NextAction["kind"].(string) {
				goto OK
			}
		}
		return nil, fmt.Errorf("session: model proposed unsupported action %v", assessment.NextAction["kind"])
	OK:
	}
	safe := map[string]any{
		"state":           assessment.State,
		"visible_text":    assessment.VisibleText,
		"confidence":      assessment.Confidence,
		"goal_complete":   assessment.GoalComplete,
		"reason":          assessment.Reason,
		"expected_result": assessment.ExpectedResult,
		"next_action":     nil,
	}
	if assessment.NextAction != nil {
		safe["next_action"] = actions.LoggedAction(assessment.NextAction)
	}
	s.mu.Lock()
	s.lastAssessment = safe
	s.lastInterpretation = obs["id"].(string)
	if assessment.NextAction != nil && assessment.Confidence >= s.minConfidence {
		s.pending = &pendingProposal{
			ObservationID:  obs["id"].(string),
			Action:         assessment.NextAction,
			Reason:         assessment.Reason,
			ExpectedResult: assessment.ExpectedResult,
		}
	} else {
		s.pending = nil
	}
	pending := s.pending
	s.mu.Unlock()
	s.event("interpretation", map[string]any{
		"observation_id": obs["id"],
		"assessment":     safe,
		"authority":      "vision_inference",
	})
	return map[string]any{
		"observation": obs,
		"assessment": map[string]any{
			"state":           assessment.State,
			"visible_text":    assessment.VisibleText,
			"confidence":      assessment.Confidence,
			"goal_complete":   assessment.GoalComplete,
			"reason":          assessment.Reason,
			"expected_result": assessment.ExpectedResult,
			"next_action":     assessment.NextAction,
		},
		"pending": proposalToMap(pending),
	}, nil
}

// Act dispatches an action. The action must reference the latest observation.
func (s *Session) Act(action map[string]any, observationID, reason, expectedResult string) (map[string]any, error) {
	action = actions.Validate(action)
	s.mu.Lock()
	if !s.enableInput && action["kind"] != "wait" {
		s.mu.Unlock()
		return nil, fmt.Errorf("session: input disabled; connect with enable_input=true")
	}
	if s.latest == nil || observationID != s.latest.ID {
		s.mu.Unlock()
		return nil, fmt.Errorf("session: action must reference the latest observation")
	}
	if age := time.Since(s.latestCapturedAt()); age > s.maxFrameAge {
		s.mu.Unlock()
		return nil, fmt.Errorf("session: observation expired; capture again")
	}
	// Confirm capability.
	caps := s.backend.Capabilities()
	found := false
	for _, c := range caps {
		if c == action["kind"].(string) {
			found = true
			break
		}
	}
	if !found {
		s.mu.Unlock()
		return nil, fmt.Errorf("session: backend does not support action %q", action["kind"])
	}
	if err := s.backend.ValidateContext(s.latest.Status); err != nil {
		s.mu.Unlock()
		return nil, err
	}
	actionID, _ := randomID()
	before := s.latest.SHA256
	safe := actions.LoggedAction(action)
	s.event("action_started", map[string]any{
		"action_id":       actionID,
		"observation_id":  observationID,
		"action":          safe,
		"reason":          reason,
		"expected_result": expectedResult,
	})
	// Consume the evidence before sending input, even if the transport fails.
	s.latest = nil
	s.pending = nil
	s.mu.Unlock()
	receipt, err := s.backend.Execute(action)
	if err != nil {
		s.event("action_failed", map[string]any{
			"action_id":       actionID,
			"error_type":      fmt.Sprintf("%T", err),
			"target_receipt":  "unknown",
		})
		return nil, err
	}
	s.event("action_dispatched", map[string]any{
		"action_id":      actionID,
		"action":         safe,
		"transport":      receipt,
		"target_receipt": "unverified",
	})
	time.Sleep(250 * time.Millisecond)
	after, err := s.Capture()
	if err != nil {
		return nil, err
	}
	s.event("action_result", map[string]any{
		"action_id":       actionID,
		"observation_id":  after["id"],
		"screen_changed":  before != after["sha256"],
		"verification":    "screen_evidence_available; target receipt not proven",
	})
	result := map[string]any{
		"action_id":       actionID,
		"action":          safe,
		"after":           after,
		"screen_changed":  before != after["sha256"],
		"expected_result": expectedResult,
		"target_receipt":  "unverified",
	}
	s.mu.Lock()
	s.lastActionResult = result
	s.mu.Unlock()
	return result, nil
}

// ExecutePending dispatches the action proposed by the most recent
// interpretation.
func (s *Session) ExecutePending(observationID string) (map[string]any, error) {
	s.mu.Lock()
	p := s.pending
	s.mu.Unlock()
	if p == nil || p.ObservationID != observationID {
		return nil, fmt.Errorf("session: no matching proposal; inspect the current screen first")
	}
	return s.Act(p.Action, observationID, p.Reason, p.ExpectedResult)
}

// Run performs observe/act until the goal is reported complete, max-steps
// is reached or a repeated identical screen+action pair is detected.
func (s *Session) Run(goal string, maxSteps int, execute bool) (map[string]any, error) {
	if maxSteps < 1 || maxSteps > 100 {
		return nil, fmt.Errorf("session: max_steps must be 1..100")
	}
	var lastResult map[string]any
	seen := map[string]struct{}{}
	for step := 0; step <= maxSteps; step++ {
		out, err := s.Observe(goal, lastResult)
		if err != nil {
			return nil, err
		}
		s.mu.Lock()
		pending := s.pending
		s.mu.Unlock()
		if !execute || pending == nil || out["assessment"].(map[string]any)["goal_complete"].(bool) || step == maxSteps {
			return out, nil
		}
		// Detect identical screen+action repetition.
		obs, _ := json.Marshal(out["observation"])
		act, _ := json.Marshal(pending.Action)
		key := string(obs) + "|" + string(act)
		if _, dup := seen[key]; dup {
			s.event("loop_stopped", map[string]any{"reason": "repeated action on identical screen"})
			return out, nil
		}
		seen[key] = struct{}{}
		lastResult, err = s.ExecutePending(pending.ObservationID)
		if err != nil {
			return out, err
		}
	}
	return nil, nil // unreachable
}

// Summary returns the durable evidence summary for this session.
func (s *Session) Summary() map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	observations := []map[string]any{}
	actions := []map[string]any{}
	for _, e := range s.events {
		switch e["event"] {
		case "observation":
			observations = append(observations, e)
		case "action_started", "action_dispatched", "action_result", "action_failed":
			actions = append(actions, e)
		}
	}
	return map[string]any{
		"session_id":                    s.id,
		"directory":                     s.directory,
		"backend":                       s.backend.Name(),
		"event_count":                   len(s.events),
		"latest_state":                  s.lastAssessment,
		"latest_state_observation_id":   s.lastInterpretation,
		"actions":                       actions,
		"evidence":                      observations,
		"interpretation_note":           "State and completion are vision inferences; target input receipt is unverified",
	}
}

// Close flushes the ledger and writes summary.json.
func (s *Session) Close() error {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return nil
	}
	s.closed = true
	dir := s.directory
	log := s.log
	backend := s.backend
	s.mu.Unlock()
	s.event("session_closed", nil)
	summary := s.Summary()
	b, _ := json.MarshalIndent(summary, "", "  ")
	if err := os.WriteFile(filepath.Join(dir, "summary.json"), b, 0o600); err != nil {
		return err
	}
	if err := log.Close(); err != nil {
		return err
	}
	return backend.Close()
}

// --- helpers --------------------------------------------------------------

func (s *Session) latestCapturedAt() time.Time {
	if s.latest == nil {
		return time.Time{}
	}
	t, _ := time.Parse(time.RFC3339Nano, s.latest.Timestamp)
	return t
}

func (s *Session) event(kind string, details map[string]any) {
	item := map[string]any{
		"schema_version": schemaVersion,
		"session_id":     s.id,
		"sequence":       len(s.events) + 1,
		"timestamp":      utcNow(),
		"event":          kind,
	}
	for k, v := range details {
		item[k] = v
	}
	b, err := json.Marshal(item)
	if err != nil {
		return
	}
	s.log.Write(b)
	s.log.Write([]byte("\n"))
	s.log.Sync()
	s.events = append(s.events, item)
}

func proposalToMap(p *pendingProposal) map[string]any {
	if p == nil {
		return nil
	}
	return map[string]any{
		"observation_id":  p.ObservationID,
		"action":          actions.LoggedAction(p.Action),
		"reason":          p.Reason,
		"expected_result": p.ExpectedResult,
	}
}

func randomID() (string, error) {
	var b [16]byte
	if _, err := io.ReadFull(rand.Reader, b[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(b[:]), nil
}

func newID() (string, error) {
	r, err := randomID()
	if err != nil {
		return "", err
	}
	return time.Now().UTC().Format("20060102T150405Z") + "-" + r[:12], nil
}

func utcNow() string {
	return time.Now().UTC().Format(time.RFC3339Nano)
}

// EncodePNG encodes the supplied image as PNG into a 0600 file.
func EncodePNG(path string, img image.Image) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	defer f.Close()
	return png.Encode(f, img)
}

// MakeRoot creates the session root directory if missing.
func MakeRoot(root string) error {
	if root == "" {
		root = os.Getenv("KVM_SESSION_ROOT")
	}
	if root == "" {
		root = filepath.Join(os.Getenv("HOME"), ".local/state/kvm-agent/sessions")
	}
	return os.MkdirAll(root, 0o700)
}

package session

import (
	"image"
	"os"
	"strings"
	"testing"

	"kvm-agent/internal/actions"
)

// fakeBackend implements a deterministic backend for session tests.
type fakeBackend struct {
	frames    []image.Image
	calls     int
	caps      []string
}

func (f *fakeBackend) Name() string          { return "fake" }
func (f *fakeBackend) Capabilities() []string { return f.caps }
func (f *fakeBackend) Capture() (image.Image, map[string]any, error) {
	idx := f.calls
	if len(f.frames) == 0 {
		return image.Rect(0, 0, 100, 50), map[string]any{"id": idx}, nil
	}
	if idx >= len(f.frames) {
		idx = len(f.frames) - 1
	}
	f.calls++
	return f.frames[idx], map[string]any{"id": idx}, nil
}
func (f *fakeBackend) ValidateContext(map[string]any) error { return nil }
func (f *fakeBackend) Execute(action map[string]any) (map[string]any, error) {
	return map[string]any{"transport": "fake"}, nil
}
func (f *fakeBackend) Close() error { return nil }

func TestInputDisabledRejectsAction(t *testing.T) {
	s, err := New(&fakeBackend{caps: []string{"press", "wait"}}, Options{EnableInput: false, Root: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	obs, err := s.Capture()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Act(map[string]any{"kind": "press", "key": "enter"}, obs["id"].(string), "", ""); err == nil {
		t.Errorf("expected error when input disabled")
	}
}

func TestStaleObservationRejected(t *testing.T) {
	s, err := New(&fakeBackend{caps: []string{"press", "wait"}}, Options{EnableInput: true, Root: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	first, err := s.Capture()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Capture(); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Act(map[string]any{"kind": "press", "key": "enter"}, first["id"].(string), "", ""); err == nil {
		t.Errorf("expected stale observation rejection")
	}
}

func TestRejectionAfterTransportFailure(t *testing.T) {
	b := &fakeBackend{caps: []string{"press", "wait"}}
	s, err := New(b, Options{EnableInput: true, Root: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	obs, err := s.Capture()
	if err != nil {
		t.Fatal(err)
	}
	// Wrap the execute to fail
	failBackend := &failingBackend{fakeBackend: b}
	s.backend = failBackend
	if _, err := s.Act(map[string]any{"kind": "press", "key": "enter"}, obs["id"].(string), "", ""); err == nil {
		t.Errorf("expected failure")
	}
	if s.latest != nil {
		t.Errorf("latest observation should be cleared after transport failure")
	}
}

type failingBackend struct {
	*fakeBackend
}

func (f *failingBackend) Execute(action map[string]any) (map[string]any, error) {
	return nil, errTest{msg: "boom"}
}

type errTest struct{ msg string }

func (e errTest) Error() string { return e.msg }

func TestRedactionInEvents(t *testing.T) {
	s, err := New(&fakeBackend{caps: []string{"type", "wait"}}, Options{EnableInput: true, Root: t.TempDir()})
	if err != nil {
		t.Fatal(err)
	}
	secret := "SuperSecretPassword!"
	obs, err := s.Capture()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Act(map[string]any{"kind": "type", "text": secret}, obs["id"].(string), "", ""); err != nil {
		t.Fatal(err)
	}
	s.Close()
	data := readFile(t, s.directory+"/events.jsonl")
	if strings.Contains(data, secret) {
		t.Errorf("typed text leaked into evidence log")
	}
}

func readFile(t *testing.T, path string) string {
	t.Helper()
	data, err := readAll(path)
	if err != nil {
		t.Fatal(err)
	}
	return data
}

func readAll(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

// drop the unused import warning
var _ = actions.AllowedActionKinds

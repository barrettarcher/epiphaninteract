package ocr

import (
	"errors"
	"os/exec"
	"strings"
	"testing"
)

func TestRunMissingBinary(t *testing.T) {
	if _, err := exec.LookPath("tesseract"); err == nil {
		t.Skip("tesseract is installed; missing-binary path not exercised")
	}
	_, err := Run("/nonexistent.png", Options{})
	if !errors.Is(err, ErrTesseractMissing) {
		t.Errorf("expected ErrTesseractMissing, got %v", err)
	}
}

func TestRunMissingImage(t *testing.T) {
	if _, err := exec.LookPath("tesseract"); err != nil {
		t.Skip("tesseract not installed")
	}
	_, err := Run("/tmp/kvm-agent-missing.png", Options{})
	if err == nil {
		t.Errorf("expected error for missing image")
	}
	if !strings.Contains(err.Error(), "tesseract") {
		t.Errorf("error should mention tesseract: %v", err)
	}
}

func TestRunLanguageDefault(t *testing.T) {
	if _, err := exec.LookPath("tesseract"); err != nil {
		t.Skip("tesseract not installed")
	}
	r, err := Run("/tmp/kvm-agent-missing.png", Options{})
	if err != nil {
		// The binary exists but the image doesn't, so an error is expected;
		// we only care that we got past the language defaulting code path
		// without crashing earlier.
		return
	}
	if r.Language != "eng" {
		t.Errorf("expected default language eng, got %q", r.Language)
	}
}

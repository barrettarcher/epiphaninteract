// Package ocr is a thin wrapper around the tesseract binary. The kvm-agent
// itself does not embed any OCR model; the agent assumes the operator has
// installed tesseract on the bench machine. When it is missing, the helper
// returns a descriptive error rather than panicking, so Rundeck jobs can
// surface the dependency problem instead of timing out.
package ocr

import (
	"bytes"
	"errors"
	"fmt"
	"os/exec"
	"strings"
	"time"

	"context"
)

// Result is the recognised text from one image.
type Result struct {
	Text      string    `json:"text"`
	Lines     []string  `json:"lines"`
	Engine    string    `json:"engine"`
	Language  string    `json:"language"`
	ElapsedMs int64     `json:"elapsed_ms"`
	Image     string    `json:"image,omitempty"`
}

// Options controls a single Run invocation.
type Options struct {
	// Language is the tesseract language code (default "eng").
	Language string
	// PSM is the optional page segmentation mode (e.g. 6 for "single block").
	PSM int
	// ExtraArgs are passed to tesseract verbatim after the image and stdout
	// placeholder. Use sparingly; the wrapper makes no attempt to validate
	// or quote them.
	ExtraArgs []string
	// Timeout bounds the tesseract invocation.
	Timeout time.Duration
}

// ErrTesseractMissing is returned when the tesseract binary is not on PATH.
var ErrTesseractMissing = errors.New("ocr: tesseract binary not found on PATH")

// Run executes tesseract on the supplied image and returns the recognised
// text. The image must be a format tesseract handles natively (PNG, TIFF,
// JPEG, PNM).
func Run(imagePath string, opts Options) (Result, error) {
	path, err := exec.LookPath("tesseract")
	if err != nil {
		return Result{}, ErrTesseractMissing
	}
	lang := opts.Language
	if lang == "" {
		lang = "eng"
	}
	args := []string{imagePath, "-", "-l", lang}
	if opts.PSM != 0 {
		args = append(args, "--psm", fmt.Sprintf("%d", opts.PSM))
	}
	args = append(args, opts.ExtraArgs...)

	var ctx context.Context
	var cancel context.CancelFunc
	if opts.Timeout > 0 {
		ctx, cancel = deadlineContext(opts.Timeout)
		defer cancel()
	}
	var cmd *exec.Cmd
	if ctx != nil {
		cmd = exec.CommandContext(ctx, path, args...)
	} else {
		cmd = exec.Command(path, args...)
	}
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	start := time.Now()
	err = cmd.Run()
	elapsed := time.Since(start)
	if err != nil {
		return Result{}, fmt.Errorf("ocr: tesseract failed: %w: %s", err, strings.TrimSpace(stderr.String()))
	}
	text := stdout.String()
	var lines []string
	for _, l := range strings.Split(text, "\n") {
		l = strings.TrimSpace(l)
		if l == "" {
			continue
		}
		lines = append(lines, l)
	}
	version := versionString(path)
	return Result{
		Text:      text,
		Lines:     lines,
		Engine:    version,
		Language:  lang,
		ElapsedMs: elapsed.Milliseconds(),
		Image:     imagePath,
	}, nil
}

func versionString(path string) string {
	cmd := exec.Command(path, "--version")
	out, err := cmd.Output()
	if err != nil {
		return "tesseract (unknown version)"
	}
	return strings.TrimSpace(string(out))
}

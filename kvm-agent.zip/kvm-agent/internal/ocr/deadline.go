package ocr

import (
	"context"
	"time"
)

// deadlineContext returns a context that is cancelled after d. The cancel
// function is wired to fire when the subprocess exits (see Run).
func deadlineContext(d time.Duration) (context.Context, func()) {
	return context.WithTimeout(context.Background(), d)
}

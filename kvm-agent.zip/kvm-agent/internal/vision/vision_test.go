package vision

import (
	"encoding/json"
	"testing"
)

func TestParseAssessmentValid(t *testing.T) {
	in := map[string]any{
		"state":           "BIOS",
		"visible_text":    "Boot",
		"confidence":      0.9,
		"goal_complete":   false,
		"reason":          "Menu",
		"expected_result": "None",
		"next_action": map[string]any{
			"kind": "wait",
			"seconds": 1.0,
		},
	}
	b, _ := json.Marshal(in)
	a, err := ParseAssessment(string(b))
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if a.State != "BIOS" || a.Confidence != 0.9 || a.NextAction["kind"].(string) != "wait" {
		t.Errorf("unexpected assessment: %+v", a)
	}
}

func TestParseAssessmentInvalid(t *testing.T) {
	for _, in := range []string{
		`{"confidence": 1.5}`,
		`{"state":"a","confidence":0.5,"goal_complete":true,"next_action":{"kind":"wait","seconds":1}}`,
		`not json`,
	} {
		if _, err := ParseAssessment(in); err == nil {
			t.Errorf("expected error for %s", in)
		}
	}
}

func TestParseAssessmentFenced(t *testing.T) {
	cases := []string{
		"```json\n{\"state\":\"a\",\"visible_text\":\"b\",\"confidence\":0.5,\"goal_complete\":false,\"reason\":\"r\",\"expected_result\":\"e\",\"next_action\":null}\n```",
		"\n  {\"state\":\"a\",\"visible_text\":\"b\",\"confidence\":0.5,\"goal_complete\":false,\"reason\":\"r\",\"expected_result\":\"e\",\"next_action\":null}  \n",
	}
	for _, c := range cases {
		if _, err := ParseAssessment(c); err != nil {
			t.Errorf("expected success for %q, got %v", c, err)
		}
	}
}

func TestAssess(t *testing.T) {
	t.Skip("requires a TCP listener that the sandbox blocks; covered manually")
}

func TestRejectEmbeddedCredentials(t *testing.T) {
	if _, err := NewClient("http://user:pass@127.0.0.1:1/v1", "model", ""); err == nil {
		t.Error("expected error for embedded credentials")
	}
}

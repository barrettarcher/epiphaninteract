package textcheck

import "testing"

func TestCheckAny(t *testing.T) {
	res, ok, err := Check([]string{"Apple", "Pear"}, "I have an Apple today", Options{CaseInsensitive: false})
	if err != nil {
		t.Fatal(err)
	}
	if !ok {
		t.Errorf("expected any match")
	}
	if len(res) != 2 || !res[0].Matched || res[1].Matched {
		t.Errorf("unexpected results: %+v", res)
	}
	if res[0].MatchText != "Apple" {
		t.Errorf("unexpected match text: %q", res[0].MatchText)
	}
}

func TestCheckAll(t *testing.T) {
	_, ok, _ := Check([]string{"Apple", "Pear"}, "I have an apple today", Options{RequireAll: true})
	if ok {
		t.Errorf("expected all-miss to be reported as fail")
	}
	_, ok, _ = Check([]string{"apple", "today"}, "I have an apple today", Options{RequireAll: true})
	if !ok {
		t.Errorf("expected all-hit to be reported as pass")
	}
}

func TestCheckCaseInsensitive(t *testing.T) {
	_, ok, _ := Check([]string{"APPLE"}, "apple", Options{CaseInsensitive: true})
	if !ok {
		t.Errorf("expected case-insensitive hit")
	}
}

func TestCheckBadPattern(t *testing.T) {
	res, _, _ := Check([]string{"["}, "anything", Options{})
	if len(res) != 1 || res[0].Error == "" {
		t.Errorf("expected per-pattern error, got %+v", res)
	}
}

func TestCheckEmpty(t *testing.T) {
	if _, _, err := Check(nil, "anything", Options{}); err == nil {
		t.Errorf("expected error when no patterns supplied")
	}
}

func TestCheckPosition(t *testing.T) {
	res, _, _ := Check([]string{"Apple"}, "first Apple second", Options{})
	if res[0].Position != 6 {
		t.Errorf("expected position 6, got %d", res[0].Position)
	}
}

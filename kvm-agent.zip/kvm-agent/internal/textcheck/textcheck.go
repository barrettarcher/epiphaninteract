// Package textcheck applies one or more regex patterns to a captured OCR
// string and records which patterns matched, where they matched, and how
// many of them matched. The package is independent of the OCR engine;
// callers supply the recognised text.
package textcheck

import (
	"fmt"
	"regexp"
	"strings"
)

// Match describes the result of testing a single regex against the OCR text.
type Match struct {
	Pattern   string `json:"pattern"`
	Matched   bool   `json:"matched"`
	MatchText string `json:"match_text,omitempty"`
	Position  int    `json:"position,omitempty"`
	Error     string `json:"error,omitempty"`
}

// Options controls Check (global Options).
type Options struct {
	// CaseInsensitive makes every pattern case-insensitive.
	CaseInsensitive bool
	// RequireAll makes Check return Matched=true only when every supplied
	// pattern matches. Otherwise any single match is sufficient.
	RequireAll bool
	// Pattern may contain "^" / "$" anchors; the wrapper does not add any
	// of its own.
}

// Check compiles each supplied pattern (with the optional case-insensitive
// flag) and runs them over the text. The returned slice mirrors the input
// order and exposes the first match (or the compile error) per pattern.
func Check(patterns []string, text string, opts Options) ([]Match, bool, error) {
	if len(patterns) == 0 {
		return nil, false, fmt.Errorf("textcheck: at least one pattern is required")
	}
	results := make([]Match, 0, len(patterns))
	allOK := true
	anyOK := false
	for _, p := range patterns {
		source := p
		if opts.CaseInsensitive && !strings.HasPrefix(source, "(?i)") {
			source = "(?i)" + source
		}
		re, err := regexp.Compile(source)
		if err != nil {
			results = append(results, Match{Pattern: p, Error: err.Error()})
			allOK = false
			continue
		}
		loc := re.FindStringIndex(text)
		if loc == nil {
			results = append(results, Match{Pattern: p, Matched: false})
			allOK = false
			continue
		}
		results = append(results, Match{
			Pattern:   p,
			Matched:   true,
			MatchText: text[loc[0]:loc[1]],
			Position:  loc[0],
		})
		anyOK = true
	}
	if opts.RequireAll {
		return results, allOK, nil
	}
	return results, anyOK, nil
}

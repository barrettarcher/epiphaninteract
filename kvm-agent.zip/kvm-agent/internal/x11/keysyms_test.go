package x11

import "testing"

func TestResolveKeysym(t *testing.T) {
	cases := []struct {
		name string
		want uint32
		ok   bool
	}{
		{"Return", 0xff0d, true},
		{"BackSpace", 0xff08, true},
		{"enter", 0xff0d, true},
		{"ctrl", 0xffe3, true},
		{"a", 0x0061, true},
		{"f1", 0xffbe, true},
		{"f12", 0xffc9, true},
		{"f13", 0, false},
		{"é", 0, false},
	}
	for _, c := range cases {
		got, ok := ResolveKeysym(c.name)
		if ok != c.ok || got != c.want {
			t.Errorf("ResolveKeysym(%q) = (%d, %v), want (%d, %v)", c.name, got, ok, c.want, c.ok)
		}
	}
}

func TestParseDisplayLocal(t *testing.T) {
	t.Setenv("DISPLAY", "")
	cases := []struct {
		in   string
		net  string
		addr string
	}{
		{":0", "unix", "/tmp/.X11-unix/X0"},
		{":1.0", "unix", "/tmp/.X11-unix/X1"},
		{"unix:2", "unix", "/tmp/.X11-unix/X2"},
		{"localhost:3", "tcp", "localhost:6003"},
	}
	for _, c := range cases {
		net, a, _, err := ParseDisplay(c.in)
		if err != nil {
			t.Errorf("ParseDisplay(%q) returned error: %v", c.in, err)
			continue
		}
		if net != c.net || a != c.addr {
			t.Errorf("ParseDisplay(%q) = (%q, %q), want (%q, %q)", c.in, net, a, c.net, c.addr)
		}
	}
	t.Setenv("DISPLAY", ""); if _, _, _, err := ParseDisplay("not a display"); err == nil {
		t.Errorf("expected error for invalid display")
	}
	if _, _, _, err := ParseDisplay(""); err == nil {
		t.Errorf("expected error for empty display")
	}
}

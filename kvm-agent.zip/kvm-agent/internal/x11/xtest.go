// XTEST extension helpers (FakeInput).
//
// X11 XTEST event types used here:
//   KeyPress   = 2
//   KeyRelease = 3
//   ButtonPress = 4
//   ButtonRelease = 5
//   MotionNotify = 6
package x11

import (
	"encoding/binary"
	"errors"
)

// ErrXTESTUnavailable is returned when XTEST is not advertised on the display.
var ErrXTESTUnavailable = errors.New("x11: XTEST extension not present")

// X11 input event types for XTEST FakeInput.
const (
	EventKeyPress      byte = 2
	EventKeyRelease    byte = 3
	EventButtonPress   byte = 4
	EventButtonRelease byte = 5
	EventMotionNotify  byte = 6
)

// Button identifiers for XTEST.
const (
	ButtonLeft   byte = 1
	ButtonMiddle byte = 2
	ButtonRight  byte = 3
	// Vertical wheel: button 4 = up, 5 = down.
	ButtonWheelUp   byte = 4
	ButtonWheelDown byte = 5
)

// FakeInput sends a synthetic X11 event through XTEST.
//
//   typ     - event type (KeyPress, MotionNotify, ButtonPress, etc.)
//   detail  - keycode for key events, button number for button events,
//             0 for motion.
//   x, y    - for MotionNotify, root coordinates; else they are ignored.
//   delay   - server delay in milliseconds; pass 0 for CurrentTime.
func (c *Conn) FakeInput(typ byte, detail byte, x, y int16, delay uint32) error {
	if !c.hasXTEST {
		return ErrXTESTUnavailable
	}
	// XTEST FakeInput encoding (after major opcode):
	//   1 byte type
	//   1 byte detail
	//   2 bytes pad
	//   4 bytes delay
	//   4 bytes root window
	//   2 bytes rootX
	//   2 bytes rootY
	//   2 bytes pad
	pad := (4 - (8 % 4)) % 4 // 0
	b := make([]byte, 28)
	b[0] = typ
	b[1] = detail
	binary.LittleEndian.PutUint32(b[4:8], delay)
	binary.LittleEndian.PutUint32(b[8:12], c.root)
	binary.LittleEndian.PutUint16(b[12:14], uint16(x))
	binary.LittleEndian.PutUint16(b[14:16], uint16(y))
	_ = pad
	return c.sendNoReply(c.xtestMajor, b)
}

// FakeKeyPress / FakeKeyRelease helpers.
func (c *Conn) FakeKeyPress(keycode uint8) error {
	return c.FakeInput(EventKeyPress, keycode, 0, 0, 0)
}
func (c *Conn) FakeKeyRelease(keycode uint8) error {
	return c.FakeInput(EventKeyRelease, keycode, 0, 0, 0)
}
func (c *Conn) FakeButtonPress(button byte) error {
	return c.FakeInput(EventButtonPress, button, 0, 0, 0)
}
func (c *Conn) FakeButtonRelease(button byte) error {
	return c.FakeInput(EventButtonRelease, button, 0, 0, 0)
}

// FakeMotion sends a MotionNotify to (x, y) in root coordinates.
func (c *Conn) FakeMotion(x, y int16) error {
	return c.FakeInput(EventMotionNotify, 0, x, y, 0)
}

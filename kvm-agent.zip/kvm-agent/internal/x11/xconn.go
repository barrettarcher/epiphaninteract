// Minimal pure-Go X11 client.
//
// The implementation supports only the requests used by the project:
// connection setup, InternAtom, GetProperty, GetGeometry, GetImage,
// QueryTree, GetKeyboardMapping, ConfigureWindow, WarpPointer, SetInputFocus,
// GetInputFocus and TranslateCoordinates, plus the XTEST extension's
// FakeInput.
//
// All multi-byte values on the wire are little-endian (the modern X11 default
// after the success byte). Errors, replies and events are read with strict
// length handling; the client never assumes a request succeeded silently.
package x11

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
)

// Conn represents a single X11 server connection.
type Conn struct {
	conn net.Conn

	mu      sync.Mutex
	seq     uint16
	root    uint32
	visual  uint32
	screenW uint16
	screenH uint16

	atomCache  map[string]uint32
	keymap     []uint32
	minKeycode uint8
	keysymsPer uint8

	xtestMajor byte
	hasXTEST   bool
}

type Atom = uint32

const (
	AtomNone        uint32 = 0
	AtomAnyProperty uint32 = 0
)

// ParseDisplay turns a $DISPLAY value into a network/address pair.
func ParseDisplay(name string) (network, address string, displayNum int, err error) {
	if name == "" {
		name = os.Getenv("DISPLAY")
	}
	if name == "" {
		return "", "", 0, errors.New("DISPLAY is empty")
	}
	host := ""
	rest := name
	if strings.HasPrefix(rest, ":") {
		rest = "unix" + rest
	}
	if i := strings.Index(rest, ":"); i >= 0 {
		host = rest[:i]
		rest = rest[i+1:]
	}
	dispStr := rest
	if i := strings.Index(dispStr, "."); i >= 0 {
		dispStr = dispStr[:i]
	}
	num, err := strconv.Atoi(dispStr)
	if err != nil || num < 0 {
		return "", "", 0, fmt.Errorf("invalid DISPLAY %q", name)
	}
	if host == "" || host == "unix" {
		return "unix", fmt.Sprintf("/tmp/.X11-unix/X%d", num), num, nil
	}
	return "tcp", net.JoinHostPort(host, fmt.Sprintf("%d", 6000+num)), num, nil
}

// Connect dials the X server indicated by displayName (or $DISPLAY).
func Connect(displayName string) (*Conn, error) {
	network, address, _, err := ParseDisplay(displayName)
	if err != nil {
		return nil, err
	}
	sock, err := net.Dial(network, address)
	if err != nil {
		return nil, fmt.Errorf("x11: dial %s://%s: %w", network, address, err)
	}
	c := &Conn{conn: sock, seq: 0, atomCache: map[string]uint32{}}
	if err := c.setup(); err != nil {
		sock.Close()
		return nil, err
	}
	if err := c.cacheAtoms(); err != nil {
		sock.Close()
		return nil, err
	}
	if err := c.cacheKeyboard(); err != nil {
		sock.Close()
		return nil, err
	}
	if err := c.queryXTEST(); err != nil {
		c.hasXTEST = false
	}
	return c, nil
}

func (c *Conn) Close() error                  { return c.conn.Close() }
func (c *Conn) Root() uint32                  { return c.root }
func (c *Conn) ScreenSize() (uint16, uint16)  { return c.screenW, c.screenH }
func (c *Conn) HasXTEST() bool                { return c.hasXTEST }
func (c *Conn) XTESTMajorOpcode() byte        { return c.xtestMajor }

// InternAtom interns a name. Subsequent calls hit the cache.
func (c *Conn) InternAtom(name string) (uint32, error) {
	c.mu.Lock()
	if a, ok := c.atomCache[name]; ok {
		c.mu.Unlock()
		return a, nil
	}
	c.mu.Unlock()
	var rep internAtomReply
	if err := c.roundTrip(16, encodeInternAtom(name), &rep); err != nil {
		return 0, err
	}
	c.mu.Lock()
	c.atomCache[name] = rep.Atom
	c.mu.Unlock()
	return rep.Atom, nil
}

// GetProperty reads the value of a window property.
func (c *Conn) GetProperty(window uint32, prop, typ uint32, longLen, offset uint32) ([]byte, error) {
	var reply getPropertyReply
	if err := c.roundTrip(91, encodeGetProperty(window, prop, typ, longLen, offset), &reply); err != nil {
		return nil, err
	}
	if reply.BytesAfter > 0 {
		return nil, fmt.Errorf("x11 GetProperty: %d bytes after, increase long_len", reply.BytesAfter)
	}
	return reply.Value, nil
}

// Geometry is the geometry of a drawable.
type Geometry struct {
	X, Y          int16
	Width, Height uint16
	Depth         uint8
	BorderWidth   uint16
}

func (c *Conn) GetGeometry(window uint32) (Geometry, error) {
	var reply getGeometryReply
	if err := c.roundTrip(14, encodeGetGeometry(window), &reply); err != nil {
		return Geometry{}, err
	}
	return reply.G, nil
}

func (c *Conn) QueryTree(window uint32) (root, parent uint32, children []uint32, err error) {
	var reply queryTreeReply
	if err := c.roundTrip(15, encodeQueryTree(window), &reply); err != nil {
		return 0, 0, nil, err
	}
	return reply.Root, reply.Parent, reply.Children, nil
}

// GetImage captures a region of the screen (ZPixmap).
func (c *Conn) GetImage(drawable uint32, x, y int16, w, h uint16) ([]byte, error) {
	var reply getImageReply
	if err := c.roundTrip(88, encodeGetImage(2, drawable, x, y, w, h, 0xffffffff), &reply); err != nil {
		return nil, err
	}
	return reply.Value, nil
}

// WarpPointer moves the logical pointer to (dstX, dstY) in dstWindow's space.
func (c *Conn) WarpPointer(srcWindow, dstWindow uint32, dstX, dstY int16) error {
	return c.sendNoReply(41, encodeWarpPointer(srcWindow, dstWindow, 0, 0, dstX, dstY))
}

// TranslateCoordinates translates (srcX, srcY) in srcWindow into dstWindow's
// coordinate space.
func (c *Conn) TranslateCoordinates(srcWindow, dstWindow uint32, srcX, srcY int16) (bool, int16, int16, error) {
	var reply translateCoordsReply
	if err := c.roundTrip(38, encodeTranslateCoordinates(srcWindow, dstWindow, srcX, srcY), &reply); err != nil {
		return false, 0, 0, err
	}
	return reply.SameScreen != 0, reply.ChildX, reply.ChildY, nil
}

func (c *Conn) SetInputFocus(window uint32) error {
	return c.sendNoReply(42, encodeSetInputFocus(2, 0, window))
}

func (c *Conn) GetInputFocus() (uint32, error) {
	var reply getInputFocusReply
	if err := c.roundTrip(23, encodeGetInputFocus(), &reply); err != nil {
		return 0, err
	}
	return reply.Focus, nil
}

// RaiseAbove raises the window to the top of the stacking order.
func (c *Conn) RaiseAbove(window uint32) error {
	// value_mask bit 7 = Above.
	return c.sendNoReply(12, encodeConfigureWindow(window, 0x80, []uint32{0}))
}

// GetKeyboardMapping returns the server's keysym map.
func (c *Conn) GetKeyboardMapping() (minKey uint8, maxKey uint8, keysymsPer uint8, table []uint32, err error) {
	c.mu.Lock()
	if len(c.keymap) > 0 {
		mk := c.minKeycode
		per := c.keysymsPer
		out := make([]uint32, len(c.keymap))
		copy(out, c.keymap)
		c.mu.Unlock()
		return mk, mk + uint8(len(out)/int(per)) - 1, per, out, nil
	}
	c.mu.Unlock()
	var reply getKeyboardMappingReply
	if err := c.roundTrip(101, encodeGetKeyboardMapping(8, 32-8+1), &reply); err != nil {
		return 0, 0, 0, nil, err
	}
	c.mu.Lock()
	c.minKeycode = reply.MinKeycode
	c.keysymsPer = reply.KeysymsPer
	c.keymap = reply.Keysyms
	c.mu.Unlock()
	return reply.MinKeycode, reply.MinKeycode + uint8(len(reply.Keysyms)/int(reply.KeysymsPer)) - 1, reply.KeysymsPer, reply.Keysyms, nil
}

// LookupKeycode searches the cached keyboard map for a keysym.
func (c *Conn) LookupKeycode(keysym uint32) (keycode uint8, group int, ok bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	minK := int(c.minKeycode)
	per := int(c.keysymsPer)
	if per == 0 || len(c.keymap) == 0 {
		return 0, 0, false
	}
	for i := 0; i < len(c.keymap); i += per {
		for g := 0; g < per; g++ {
			if c.keymap[i+g] == keysym {
				return uint8(minK + i/per), g, true
			}
		}
	}
	return 0, 0, false
}

func (c *Conn) roundTrip(opcode byte, data []byte, reply interface{}) error {
	c.mu.Lock()
	c.seq++
	seq := c.seq
	c.mu.Unlock()
	if err := c.writeRequest(opcode, data); err != nil {
		return err
	}
	if reply == nil {
		return nil
	}
	return c.readReply(seq, opcode, reply)
}

func (c *Conn) sendNoReply(opcode byte, data []byte) error {
	return c.roundTrip(opcode, data, nil)
}

func (c *Conn) writeRequest(opcode byte, data []byte) error {
	pad := (4 - (len(data) % 4)) % 4
	length := uint16(4 + len(data) + pad)
	buf := make([]byte, 4, length)
	buf[0] = opcode
	binary.LittleEndian.PutUint16(buf[2:4], uint16(length/4))
	if _, err := c.conn.Write(buf); err != nil {
		return err
	}
	if len(data) > 0 {
		if _, err := c.conn.Write(data); err != nil {
			return err
		}
	}
	for i := 0; i < pad; i++ {
		if _, err := c.conn.Write([]byte{0}); err != nil {
			return err
		}
	}
	return nil
}

func (c *Conn) readReply(wantSeq uint16, wantOpcode byte, out interface{}) error {
	var hdr [32]byte
	if _, err := io.ReadFull(c.conn, hdr[:]); err != nil {
		return err
	}
	success := hdr[0] == 1
	if !success {
		errcode := hdr[1]
		extra := binary.LittleEndian.Uint32(hdr[4:8]) * 4
		if extra > 24 {
			rest := make([]byte, extra-24)
			if _, err := io.ReadFull(c.conn, rest); err != nil {
				return err
			}
		}
		return fmt.Errorf("x11: error code=%d", errcode)
	}
	seq := binary.LittleEndian.Uint16(hdr[2:4])
	extraLen := binary.LittleEndian.Uint32(hdr[4:8]) * 4
	if seq != wantSeq {
		return fmt.Errorf("x11: reply seq=%d want=%d", seq, wantSeq)
	}
	body := append([]byte{}, hdr[8:32]...)
	if extraLen > 24 {
		rest := make([]byte, extraLen-24)
		if _, err := io.ReadFull(c.conn, rest); err != nil {
			return err
		}
		body = append(body, rest...)
	}
	return decodeReply(out, wantOpcode, body)
}

// --- Setup handshake ------------------------------------------------------

func (c *Conn) setup() error {
	req := []byte{
		'l', 0,
		11, 0, 0, 0,
		0, 0, 0, 0,
	}
	if _, err := c.conn.Write(req); err != nil {
		return err
	}
	var hdr [8]byte
	if _, err := io.ReadFull(c.conn, hdr[:]); err != nil {
		return err
	}
	success := hdr[0]
	protoMaj := binary.LittleEndian.Uint16(hdr[2:4])
	if protoMaj != 11 {
		return fmt.Errorf("x11: unsupported protocol version %d", protoMaj)
	}
	if success == 0 {
		buf := make([]byte, 4096)
		n, _ := c.conn.Read(buf)
		return fmt.Errorf("x11: setup failed: %s", string(bytes.TrimRight(buf[:n], "\x00")))
	}
	if success != 1 {
		return fmt.Errorf("x11: unexpected setup byte 0x%02x", success)
	}
	var more [24]byte
	if _, err := io.ReadFull(c.conn, more[:]); err != nil {
		return err
	}
	extraLen := binary.LittleEndian.Uint32(more[0:4])
	vendorLen := binary.LittleEndian.Uint16(more[16:18])
	screenCount := more[20]
	vendorBuf := make([]byte, ((int(vendorLen)+3)&^3))
	if _, err := io.ReadFull(c.conn, vendorBuf); err != nil {
		return err
	}
	scn := make([]byte, int(screenCount)*40)
	if _, err := io.ReadFull(c.conn, scn); err != nil {
		return err
	}
	if screenCount == 0 {
		return errors.New("x11: no screens reported")
	}
	c.root = binary.LittleEndian.Uint32(scn[0:4])
	c.visual = binary.LittleEndian.Uint32(scn[20:24])
	c.screenW = binary.LittleEndian.Uint16(scn[24:26])
	c.screenH = binary.LittleEndian.Uint16(scn[26:28])
	_ = extraLen
	return nil
}

func (c *Conn) cacheAtoms() error {
	for _, a := range []string{
		"_NET_CLIENT_LIST",
		"_NET_WM_PID",
		"_NET_WM_NAME",
		"WM_NAME",
		"WM_PROTOCOLS",
		"UTF8_STRING",
		"STRING",
		"CARDINAL",
	} {
		if _, err := c.InternAtom(a); err != nil {
			return err
		}
	}
	return nil
}

func (c *Conn) cacheKeyboard() error {
	_, _, _, _, err := c.GetKeyboardMapping()
	return err
}

func (c *Conn) queryXTEST() error {
	var reply queryExtensionReply
	if err := c.roundTrip(99, encodeQueryExtension("XTEST"), &reply); err != nil {
		return err
	}
	if reply.Present == 0 {
		return errors.New("XTEST extension not present")
	}
	c.xtestMajor = reply.MajorOpcode
	c.hasXTEST = true
	return nil
}

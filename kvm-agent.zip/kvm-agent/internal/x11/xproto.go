// Request encoders and reply decoders for the X11 requests used by the
// project. Only the requests/replies referenced from xconn.go are present.
package x11

import (
	"encoding/binary"
	"fmt"
)

// --- Encoders -------------------------------------------------------------

func encodeInternAtom(name string) []byte {
	pad := (4 - (len(name) % 4)) % 4
	b := make([]byte, 8+len(name)+pad)
	binary.LittleEndian.PutUint16(b[0:2], uint16(len(name)))
	// onlyIfExists (1) + pad byte.
	b[2] = 0
	// 2 unused bytes after the 8-byte header; we leave them zero.
	copy(b[4:], name)
	return b
}

func encodeGetProperty(window, prop, typ uint32, longLen, offset uint32) []byte {
	b := make([]byte, 20)
	binary.LittleEndian.PutUint32(b[0:4], window)
	// delete (1) at offset 4; leave zero.
	binary.LittleEndian.PutUint32(b[8:12], prop)
	binary.LittleEndian.PutUint32(b[12:16], typ)
	binary.LittleEndian.PutUint32(b[16:20], longLen)
	_ = offset
	return b
}

func encodeGetGeometry(window uint32) []byte {
	b := make([]byte, 8)
	binary.LittleEndian.PutUint32(b[0:4], window)
	return b
}

func encodeQueryTree(window uint32) []byte {
	b := make([]byte, 8)
	binary.LittleEndian.PutUint32(b[0:4], window)
	return b
}

func encodeGetImage(format byte, drawable uint32, x, y int16, w, h uint16, planeMask uint32) []byte {
	b := make([]byte, 20)
	b[0] = 0
	binary.LittleEndian.PutUint32(b[4:8], drawable)
	binary.LittleEndian.PutUint16(b[8:10], uint16(x))
	binary.LittleEndian.PutUint16(b[10:12], uint16(y))
	binary.LittleEndian.PutUint16(b[12:14], w)
	binary.LittleEndian.PutUint16(b[14:16], h)
	binary.LittleEndian.PutUint32(b[16:20], planeMask)
	_ = format
	return b
}

func encodeConfigureWindow(window uint32, valueMask uint16, values []uint32) []byte {
	b := make([]byte, 8+4*len(values))
	binary.LittleEndian.PutUint32(b[0:4], window)
	binary.LittleEndian.PutUint16(b[4:6], valueMask)
	for i, v := range values {
		binary.LittleEndian.PutUint32(b[8+4*i:8+4*i+4], v)
	}
	return b
}

func encodeWarpPointer(srcWindow, dstWindow uint32, srcX, srcY, dstX, dstY int16) []byte {
	b := make([]byte, 20)
	binary.LittleEndian.PutUint32(b[0:4], srcWindow)
	binary.LittleEndian.PutUint32(b[4:8], dstWindow)
	binary.LittleEndian.PutUint16(b[8:10], uint16(srcX))
	binary.LittleEndian.PutUint16(b[10:12], uint16(srcY))
	binary.LittleEndian.PutUint16(b[12:14], uint16(dstX))
	binary.LittleEndian.PutUint16(b[14:16], uint16(dstY))
	return b
}

func encodeSetInputFocus(revertTo byte, time uint32, window uint32) []byte {
	b := make([]byte, 12)
	b[0] = revertTo
	binary.LittleEndian.PutUint32(b[4:8], time)
	binary.LittleEndian.PutUint32(b[8:12], window)
	return b
}

func encodeGetInputFocus() []byte { return []byte{} }

func encodeGetKeyboardMapping(firstKeycode uint8, count uint8) []byte {
	b := make([]byte, 8)
	b[0] = firstKeycode
	b[1] = count
	return b
}

func encodeQueryExtension(name string) []byte {
	pad := (4 - (len(name) % 4)) % 4
	b := make([]byte, 8+len(name)+pad)
	binary.LittleEndian.PutUint16(b[0:2], uint16(len(name)))
	copy(b[4:], name)
	return b
}

// --- Reply decoders -------------------------------------------------------

type internAtomReply struct {
	Atom uint32
	// pad[3] + length(4)
}

type getPropertyReply struct {
	Type       uint32
	BytesAfter uint32
	ValueType  uint32
	Value      []byte
}

type getGeometryReply struct {
	Depth       uint8
	Sequence    uint16
	G           Geometry
}

type queryTreeReply struct {
	Root     uint32
	Parent   uint32
	Children []uint32
}

type getImageReply struct {
	Depth uint8
	// pad[12]
	Value       []byte
}

type translateCoordsReply struct {
	SameScreen uint8
	ChildX     int16
	ChildY     int16
}

type getInputFocusReply struct {
	Focus uint32
}

type getKeyboardMappingReply struct {
	MinKeycode  uint8
	KeysymsPer  uint8
	Keysyms     []uint32
}

type queryExtensionReply struct {
	Present     uint8
	MinorOpcode uint8
	MajorOpcode byte
}

func decodeReply(dst interface{}, opcode byte, body []byte) error {
	switch v := dst.(type) {
	case *internAtomReply:
		v.Atom = binary.LittleEndian.Uint32(body[0:4])
		return nil
	case *getPropertyReply:
		v.Type = binary.LittleEndian.Uint32(body[8:12])
		v.BytesAfter = binary.LittleEndian.Uint32(body[12:16])
		// body[16:20] = value length (in bytes).
		vlen := binary.LittleEndian.Uint32(body[16:20])
		v.Value = append([]byte{}, body[32:32+vlen]...)
		return nil
	case *getGeometryReply:
		v.Depth = body[0]
		v.G.Width = binary.LittleEndian.Uint16(body[8:10])
		v.G.Height = binary.LittleEndian.Uint16(body[10:12])
		v.G.X = int16(binary.LittleEndian.Uint16(body[12:14]))
		v.G.Y = int16(binary.LittleEndian.Uint16(body[14:18]))
		v.G.BorderWidth = binary.LittleEndian.Uint16(body[18:20])
		return nil
	case *queryTreeReply:
		v.Root = binary.LittleEndian.Uint32(body[8:12])
		v.Parent = binary.LittleEndian.Uint32(body[12:16])
		count := binary.LittleEndian.Uint16(body[16:18])
		v.Children = make([]uint32, count)
		for i := 0; i < int(count); i++ {
			v.Children[i] = binary.LittleEndian.Uint32(body[32+4*i : 32+4*i+4])
		}
		return nil
	case *getImageReply:
		v.Depth = body[0]
		visual := binary.LittleEndian.Uint32(body[8:12])
		_ = visual
		vlen := binary.LittleEndian.Uint32(body[20:24])
		v.Value = append([]byte{}, body[32:32+vlen]...)
		return nil
	case *translateCoordsReply:
		v.SameScreen = body[0]
		v.ChildX = int16(binary.LittleEndian.Uint16(body[2:4]))
		v.ChildY = int16(binary.LittleEndian.Uint16(body[4:6]))
		return nil
	case *getInputFocusReply:
		v.Focus = binary.LittleEndian.Uint32(body[4:8])
		return nil
	case *getKeyboardMappingReply:
		v.MinKeycode = body[0]
		v.KeysymsPer = body[1]
		// body[8:] contains the keysym table, each 4 bytes.
		tableLen := len(body) - 8
		if tableLen < 0 {
			tableLen = 0
		}
		v.Keysyms = make([]uint32, tableLen/4)
		for i := range v.Keysyms {
			v.Keysyms[i] = binary.LittleEndian.Uint32(body[8+4*i : 8+4*i+4])
		}
		return nil
	case *queryExtensionReply:
		v.Present = body[0]
		v.MinorOpcode = body[1]
		v.MajorOpcode = body[2]
		return nil
	}
	return fmt.Errorf("x11: decode: unsupported reply for %p (%T)", dst, dst)
}

func encodeTranslateCoordinates(srcWindow, dstWindow uint32, srcX, srcY int16) []byte {
	b := make([]byte, 16)
	binary.LittleEndian.PutUint32(b[0:4], srcWindow)
	binary.LittleEndian.PutUint32(b[4:8], dstWindow)
	binary.LittleEndian.PutUint16(b[8:10], uint16(srcX))
	binary.LittleEndian.PutUint16(b[10:12], uint16(srcY))
	return b
}

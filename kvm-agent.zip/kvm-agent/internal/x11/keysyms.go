// Minimal keysym subset used by the project.
//
// Reference: X Consortium keysym definitions (keysymdef.h). Only the names
// actually used by the action validator or the strict vendor-GUI typing path
// are declared here.
package x11

import "fmt"

// Named keysyms -> X11 keysym (uint32, host byte order).
var namedKeysyms = map[string]uint32{
	"space":        0x0020,
	"exclam":       0x0021,
	"quotedbl":     0x0022,
	"numbersign":   0x0023,
	"dollar":       0x0024,
	"percent":      0x0025,
	"ampersand":    0x0026,
	"apostrophe":   0x0027,
	"parenleft":    0x0028,
	"parenright":   0x0029,
	"asterisk":     0x002a,
	"plus":         0x002b,
	"comma":        0x002c,
	"minus":        0x002d,
	"period":       0x002e,
	"slash":        0x002f,
	"0":            0x0030,
	"1":            0x0031,
	"2":            0x0032,
	"3":            0x0033,
	"4":            0x0034,
	"5":            0x0035,
	"6":            0x0036,
	"7":            0x0037,
	"8":            0x0038,
	"9":            0x0039,
	"colon":        0x003a,
	"semicolon":    0x003b,
	"less":         0x003c,
	"equal":        0x003d,
	"greater":      0x003e,
	"question":     0x003f,
	"at":           0x0040,
	"A":            0x0041,
	"B":            0x0042,
	"C":            0x0043,
	"D":            0x0044,
	"E":            0x0045,
	"F":            0x0046,
	"G":            0x0047,
	"H":            0x0048,
	"I":            0x0049,
	"J":            0x004a,
	"K":            0x004b,
	"L":            0x004c,
	"M":            0x004d,
	"N":            0x004e,
	"O":            0x004f,
	"P":            0x0050,
	"Q":            0x0051,
	"R":            0x0052,
	"S":            0x0053,
	"T":            0x0054,
	"U":            0x0055,
	"V":            0x0056,
	"W":            0x0057,
	"X":            0x0058,
	"Y":            0x0059,
	"Z":            0x005a,
	"bracketleft":  0x005b,
	"backslash":    0x005c,
	"bracketright": 0x005d,
	"asciicircum":  0x005e,
	"underscore":   0x005f,
	"grave":        0x0060,
	"a":            0x0061,
	"b":            0x0062,
	"c":            0x0063,
	"d":            0x0064,
	"e":            0x0065,
	"f":            0x0066,
	"g":            0x0067,
	"h":            0x0068,
	"i":            0x0069,
	"j":            0x006a,
	"k":            0x006b,
	"l":            0x006c,
	"m":            0x006d,
	"n":            0x006e,
	"o":            0x006f,
	"p":            0x0070,
	"q":            0x0071,
	"r":            0x0072,
	"s":            0x0073,
	"t":            0x0074,
	"u":            0x0075,
	"v":            0x0076,
	"w":            0x0077,
	"x":            0x0078,
	"y":            0x0079,
	"z":            0x007a,
	"braceleft":    0x007b,
	"bar":          0x007c,
	"braceright":   0x007d,
	"asciitilde":   0x007e,

	"Tab":       0xff09,
	"Return":    0xff0d,
	"Escape":    0xff1b,
	"BackSpace": 0xff08,
	"Delete":    0xffff,
	"Insert":    0xff63,
	"Home":      0xff50,
	"End":       0xff57,
	"Prior":     0xff55,
	"Next":      0xff56,
	"Left":      0xff51,
	"Right":     0xff53,
	"Up":        0xff52,
	"Down":      0xff54,

	"Shift_L":   0xffe1,
	"Shift_R":   0xffe2,
	"Control_L": 0xffe3,
	"Control_R": 0xffe4,
	"Alt_L":     0xffe9,
	"Alt_R":     0xffea,
	"Super_L":   0xffeb,
	"Super_R":   0xffec,

	"F1":  0xffbe,
	"F2":  0xffbf,
	"F3":  0xffc0,
	"F4":  0xffc1,
	"F5":  0xffc2,
	"F6":  0xffc3,
	"F7":  0xffc4,
	"F8":  0xffc5,
	"F9":  0xffc6,
	"F10": 0xffc7,
	"F11": 0xffc8,
	"F12": 0xffc9,
}

// ResolveKeysym returns the keysym for a logical name.
func ResolveKeysym(name string) (uint32, bool) {
	if key, ok := namedKeysyms[name]; ok {
		return key, true
	}
	switch name {
	case "ctrl":
		return namedKeysyms["Control_L"], true
	case "shift":
		return namedKeysyms["Shift_L"], true
	case "alt":
		return namedKeysyms["Alt_L"], true
	case "super":
		return namedKeysyms["Super_L"], true
	case "esc":
		return namedKeysyms["Escape"], true
	case "enter":
		return namedKeysyms["Return"], true
	case "backspace":
		return namedKeysyms["BackSpace"], true
	case "tab":
		return namedKeysyms["Tab"], true
	case "delete":
		return namedKeysyms["Delete"], true
	case "insert":
		return namedKeysyms["Insert"], true
	case "home":
		return namedKeysyms["Home"], true
	case "end":
		return namedKeysyms["End"], true
	case "pageup":
		return namedKeysyms["Prior"], true
	case "pagedown":
		return namedKeysyms["Next"], true
	case "left":
		return namedKeysyms["Left"], true
	case "right":
		return namedKeysyms["Right"], true
	case "up":
		return namedKeysyms["Up"], true
	case "down":
		return namedKeysyms["Down"], true
	}
	if len(name) == 1 {
		c := name[0]
		if c >= 0x20 && c <= 0x7e {
			return uint32(c), true
		}
	}
	if len(name) >= 2 && name[0] == 'f' {
		n := 0
		for _, ch := range name[1:] {
			if ch < '0' || ch > '9' {
				return 0, false
			}
			n = n*10 + int(ch-'0')
		}
		if n >= 1 && n <= 12 {
			return namedKeysyms[fmt.Sprintf("F%d", n)], true
		}
	}
	return 0, false
}

// Package server hosts the local browser UI. The server binds to
// 127.0.0.1 only and requires a per-launch CSRF token on every mutating
// POST.
package server

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"sync"

	_ "embed"

	"kvm-agent/internal/backends"
	"kvm-agent/internal/session"
	"kvm-agent/internal/vision"
)

//go:embed ui.html
var uiHTML string

// Server is the local UI HTTP server.
type Server struct {
	port    int
	url     string
	token   string
	srv     *http.Server
	done    chan struct{}
	stateMu sync.Mutex
	session *session.Session
	calib   *session.Session
}

// Start launches the local UI server. openBrowser is false for headless runs.
func Start(ctx context.Context, port int, openBrowser bool) (*Server, error) {
	if port == 0 {
		port = 8765
	}
	tok := newSecretToken()
	s := &Server{port: port, token: tok}
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handleIndex)
	mux.HandleFunc("/image/", s.handleImage)
	mux.HandleFunc("/api/", s.handleAPI)
	ln, err := net.Listen("tcp", "127.0.0.1:"+itoa(port))
	if err != nil {
		return nil, err
	}
	s.url = "http://127.0.0.1:" + itoa(ln.Addr().(*net.TCPAddr).Port)
	s.srv = &http.Server{Handler: mux}
	if s.done == nil {
		s.done = make(chan struct{})
	}
	go func() {
		defer close(s.done)
		if err := s.srv.Serve(ln); err != nil && err != http.ErrServerClosed {
			// leave the channel closed; caller will pick up the URL on Wait()
		}
	}()
	go func() {
		<-ctx.Done()
		s.srv.Close()
	}()
	if openBrowser {
		_ = open(s.url)
	}
	return s, nil
}

// URL returns the URL the server is listening on.
func (s *Server) URL() string { return s.url }

// Token returns the per-launch CSRF token.
func (s *Server) Token() string { return s.token }

// Wait blocks until the server exits.
func (s *Server) Wait() error {
	if s.done == nil {
		return nil
	}
	<-s.done
	return nil
}

// Close shuts the server down and closes any open sessions.
func (s *Server) Close() error {
	s.stateMu.Lock()
	defer s.stateMu.Unlock()
	if s.session != nil {
		s.session.Close()
		s.session = nil
	}
	if s.calib != nil {
		s.calib.Close()
		s.calib = nil
	}
	return s.srv.Close()
}

func (s *Server) handleIndex(w http.ResponseWriter, r *http.Request) {
	if !validHost(r, s.port) {
		http.Error(w, "forbidden host", http.StatusForbidden)
		return
	}
	body := strings.ReplaceAll(uiHTML, "'__TOKEN__'", "'"+s.token+"'")
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = w.Write([]byte(body))
}

func (s *Server) handleImage(w http.ResponseWriter, r *http.Request) {
	if !validHost(r, s.port) {
		http.Error(w, "forbidden host", http.StatusForbidden)
		return
	}
	id := strings.TrimPrefix(r.URL.Path, "/image/")
	if !regexp.MustCompile(`^[0-9a-f]{32}$`).MatchString(id) {
		http.NotFound(w, r)
		return
	}
	s.stateMu.Lock()
	sessions := []*session.Session{s.session, s.calib}
	s.stateMu.Unlock()
	for _, sess := range sessions {
		if sess == nil {
			continue
		}
		path := filepath.Join(sess.Directory(), id+".png")
		if f, err := os.Open(path); err == nil {
			defer f.Close()
			w.Header().Set("Content-Type", "image/png")
			w.Header().Set("Cache-Control", "no-store")
			_, _ = io.Copy(w, f)
			return
		}
	}
	http.NotFound(w, r)
}

func (s *Server) handleAPI(w http.ResponseWriter, r *http.Request) {
	if !validHost(r, s.port) {
		writeJSON(w, http.StatusForbidden, map[string]any{"error": "invalid host"})
		return
	}
	if r.Method != http.MethodPost {
		writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "method not allowed"})
		return
	}
	if r.Header.Get("X-KVM-Token") != s.token {
		writeJSON(w, http.StatusForbidden, map[string]any{"error": "invalid CSRF token"})
		return
	}
	body, err := io.ReadAll(io.LimitReader(r.Body, 65536))
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "read body: " + err.Error()})
		return
	}
	var payload map[string]any
	if len(body) > 0 {
		if err := json.Unmarshal(body, &payload); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid JSON: " + err.Error()})
			return
		}
	}
	apiPath := strings.TrimPrefix(r.URL.Path, "/api/")
	s.stateMu.Lock()
	sess := s.session
	calib := s.calib
	s.stateMu.Unlock()
	var result map[string]any
	switch apiPath {
	case "doctor":
		result = doctorReport()
	case "launch":
		result = map[string]any{"note": "open the vendor application directly; the agent does not start it for you"}
	case "setup-device-access":
		result, err = runDeviceAccess()
	case "calibrate":
		if calib != nil {
			calib.Close()
		}
		calib, err = newCalibration(payload)
		if err == nil {
			obs, capErr := s.calibrateAndCapture(calib)
			if capErr != nil {
				err = capErr
			} else {
				result = map[string]any{"observation": obs, "calibration": true}
			}
		}
		s.stateMu.Lock()
		s.calib = calib
		s.stateMu.Unlock()
	case "connect":
		if sess != nil {
			sess.Close()
			s.session = nil
		}
		newSess, e := newSession(payload)
		if e != nil {
			err = e
		} else {
			s.stateMu.Lock()
			s.session = newSess
			s.stateMu.Unlock()
			result = map[string]any{
				"connected":     newSess.Backend().Name(),
				"session":       newSess.ID(),
				"input_enabled": newSessionInputEnabled(payload),
			}
		}
	default:
		if sess == nil {
			err = errors.New("connect a backend first")
			break
		}
		switch apiPath {
		case "capture":
			obs, e := sess.Capture()
			if e != nil {
				err = e
			} else {
				result = map[string]any{"observation": obs}
			}
		case "inspect":
			goal, _ := payload["goal"].(string)
			if goal == "" {
				goal = "Describe visible system state"
			}
			out, e := sess.Observe(goal, nil)
			if e != nil {
				err = e
			} else {
				result = out
			}
		case "execute":
			oid, _ := payload["observation_id"].(string)
			res, e := sess.ExecutePending(oid)
			if e != nil {
				err = e
			} else {
				result = res
			}
		case "run":
			goal, _ := payload["goal"].(string)
			maxSteps := intFromPayload(payload, "max_steps", 5)
			out, e := sess.Run(goal, maxSteps, true)
			if e != nil {
				err = e
			} else {
				result = out
			}
		case "summary":
			result = sess.Summary()
		default:
			err = fmt.Errorf("unknown API operation %q", apiPath)
		}
	}
	if err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{
			"error":      err.Error(),
			"error_type": fmt.Sprintf("%T", err),
		})
		return
	}
	writeJSON(w, http.StatusOK, result)
}

// --- helpers --------------------------------------------------------------

func writeJSON(w http.ResponseWriter, code int, body map[string]any) {
	b, _ := json.Marshal(body)
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-ancestors 'none'")
	w.WriteHeader(code)
	_, _ = w.Write(b)
}

func validHost(r *http.Request, port int) bool {
	host := r.Host
	if host == "" {
		return false
	}
	if strings.HasSuffix(host, ":"+itoa(port)) {
		return strings.HasPrefix(host, "127.0.0.1") || strings.HasPrefix(host, "localhost")
	}
	return false
}

func newSecretToken() string {
	var b [24]byte
	_, _ = rand.Read(b[:])
	return base64.RawURLEncoding.EncodeToString(b[:])
}

func open(url string) error {
	for _, candidate := range []string{"xdg-open", "open", "wslview"} {
		if _, err := exec.LookPath(candidate); err == nil {
			return exec.Command(candidate, url).Start()
		}
	}
	return nil
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	digits := []byte{}
	for n > 0 {
		digits = append([]byte{byte('0' + n%10)}, digits...)
		n /= 10
	}
	if neg {
		digits = append([]byte{'-'}, digits...)
	}
	return string(digits)
}

func intFromPayload(p map[string]any, key string, def int) int {
	if v, ok := p[key]; ok {
		switch n := v.(type) {
		case float64:
			return int(n)
		case int:
			return n
		}
	}
	return def
}

// --- session construction ------------------------------------------------

func newSession(payload map[string]any) (*session.Session, error) {
	name, _ := payload["backend"].(string)
	switch name {
	case "demo", "":
		enable := boolFromPayload(payload, "enable_input")
		opts := session.Options{EnableInput: enable}
		return session.New(backends.NewDemo(), opts)
	case "kvmapp":
		windowID, _ := payload["window_id"].(string)
		vp := viewportFromPayload(payload["viewport"])
		absolute := boolFromPayload(payload, "absolute_mouse")
		enable := boolFromPayload(payload, "enable_input")
		b, err := backends.NewKvmApp("", windowID, vp, absolute)
		if err != nil {
			return nil, err
		}
		opts := session.Options{EnableInput: enable}
		if v, ok := payload["vision_url"].(string); ok && v != "" {
			model, _ := payload["model"].(string)
			apiKey, _ := payload["api_key"].(string)
			vis, err := vision.NewClient(v, model, apiKey)
			if err != nil {
				b.Close()
				return nil, err
			}
			opts.Vision = vis
		}
		return session.New(b, opts)
	}
	return nil, fmt.Errorf("unknown backend %q", name)
}

func newCalibration(payload map[string]any) (*session.Session, error) {
	windowID, _ := payload["window_id"].(string)
	if windowID == "" {
		return nil, fmt.Errorf("window id is required for calibration")
	}
	b, err := backends.NewKvmAppCalibration("", windowID)
	if err != nil {
		return nil, err
	}
	return session.New(b, session.Options{})
}

func newSessionInputEnabled(payload map[string]any) bool {
	return boolFromPayload(payload, "enable_input")
}

func viewportFromPayload(v any) [4]int {
	list, ok := v.([]any)
	if !ok || len(list) != 4 {
		return [4]int{0, 0, 0, 0}
	}
	out := [4]int{}
	for i := 0; i < 4; i++ {
		switch n := list[i].(type) {
		case float64:
			out[i] = int(n)
		case int:
			out[i] = n
		}
	}
	return out
}

func boolFromPayload(p map[string]any, key string) bool {
	if v, ok := p[key]; ok {
		if b, ok := v.(bool); ok {
			return b
		}
	}
	return false
}

func doctorReport() map[string]any {
	report := map[string]any{
		"platform": "linux",
	}
	report["video_devices"] = backends.VideoDevices()
	if windows, err := backends.FindVendorWindows(""); err == nil {
		infos := make([]map[string]any, 0, len(windows))
		for _, w := range windows {
			infos = append(infos, map[string]any{
				"window_id":   w.WindowID,
				"title":       w.Title,
				"client_size": []int{w.ClientWidth, w.ClientHeight},
			})
		}
		report["kvmapp_windows"] = infos
		report["display_error"] = nil
	} else {
		report["kvmapp_windows"] = []any{}
		report["display_error"] = err.Error()
	}
	report["session_type"] = os.Getenv("XDG_SESSION_TYPE")
	report["direct_hid_forwarding"] = "unverified"
	return report
}

func runDeviceAccess() (map[string]any, error) {
	helper, err := os.Executable()
	if err != nil {
		return nil, err
	}
	dir := filepath.Dir(helper)
	script := filepath.Join(dir, "setup-device-access")
	if _, err := os.Stat(script); err != nil {
		return nil, fmt.Errorf("device access helper missing at %s", script)
	}
	cmd := exec.Command("pkexec", script)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("device setup failed: %s", string(out))
	}
	return map[string]any{
		"output": strings.TrimSpace(string(out)),
		"rule":   "/etc/udev/rules.d/70-kvm-agent.rules",
	}, nil
}

// calibrateAndCapture returns a fresh observation from the calibration
// session, dropping any prior evidence.
func (s *Server) calibrateAndCapture(calib *session.Session) (map[string]any, error) {
	return calib.Capture()
}

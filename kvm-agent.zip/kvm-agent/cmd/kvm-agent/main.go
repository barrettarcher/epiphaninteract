// kvm-agent is a local Go port of the vision-driven KVM agent. It captures
// a target computer's screen via the vendor's video-application, sends
// frames to a vision model, and dispatches reviewed keyboard / mouse
// actions through the same vendor application.
//
// The project intentionally does not bundle any third-party SDK or driver;
// all input reaches the target by routing through the vendor GUI, and
// capture uses standard X11 / V4L2 primitives.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"kvm-agent/internal/backends"
	"kvm-agent/internal/ocr"
	"kvm-agent/internal/pdu"
	"kvm-agent/internal/session"
	"kvm-agent/internal/server"
	"kvm-agent/internal/textcheck"
	"kvm-agent/internal/vision"
)

const usage = `kvm-agent - vision-driven KVM control

Usage:
  kvm-agent <command> [flags]

Commands:
  doctor                Inspect X11, vendor, and USB environment
  demo                  Synthetic capture + click + after-capture demo
  serve [--port N] [--no-browser]
                         Start the local browser UI
  capture [--backend BACKEND ...] [--ocr] [--check-pattern REGEX ...]
                         Capture one image and exit (optionally OCR it)
  inspect [--backend BACKEND ...] [--goal GOAL]
                         Capture, interpret with the vision model, and exit
  run [--backend BACKEND ...] [--goal GOAL] [--max-steps N] [--execute]
                         Bounded autonomous loop
  check-text [--pattern REGEX] ... [--from-json FILE] [--case-insensitive] [--all]
                         Assert one (or all) of the regex patterns against a saved OCR JSON
  boot-into-bios [--backend kvmapp ...] --key DEL [--match-text REGEX ...] [--interval 200ms]
                         Spam a key during POST; OCR-detect the BIOS
  launch                Open the vendor GUI in the local desktop session
  power --pdu-host HOST [--pdu-user USER] [--pdu-pass PASS] --pdu-outlet N --pdu-action on|off|status [--pdu-style rest|legacy]
                         Talk to a DLI Web Power Switch (REST or legacy URL)
  setup-device-access   Install the udev rule for the KVM USB device
`

func main() {
	if len(os.Args) < 2 {
		fmt.Fprint(os.Stderr, usage)
		os.Exit(2)
	}
	cmd := os.Args[1]
	args := os.Args[2:]
	if err := dispatch(cmd, args); err != nil {
		out := map[string]any{"error": err.Error(), "error_type": fmt.Sprintf("%T", err)}
		b, _ := json.MarshalIndent(out, "", "  ")
		fmt.Fprintln(os.Stderr, string(b))
		os.Exit(1)
	}
}

func dispatch(cmd string, args []string) error {
	switch cmd {
	case "doctor":
		return runDoctor()
	case "demo":
		return runDemo(args)
	case "serve":
		return runServe(args)
	case "capture":
		return runCapture(args)
	case "inspect":
		return runInspect(args)
	case "run":
		return runRun(args)
	case "check-text":
		return runCheckText(args)
	case "boot-into-bios":
		return runBootIntoBios(args)
	case "launch":
		return runLaunch()
	case "power":
		return runPower(args)
	case "setup-device-access":
		return runDeviceAccess()
	default:
		return fmt.Errorf("unknown command %q", cmd)
	}
}

func runDoctor() error {
	report := map[string]any{
		"platform":       "linux",
		"video_devices":  backends.VideoDevices(),
		"session_type":   os.Getenv("XDG_SESSION_TYPE"),
	}
	if windows, err := backends.FindVendorWindows(""); err == nil {
		report["kvmapp_windows"] = windows
	} else {
		report["kvmapp_windows"] = nil
		report["display_error"] = err.Error()
	}
	report["direct_hid_forwarding"] = "unverified"
	b, _ := json.MarshalIndent(report, "", "  ")
	fmt.Println(string(b))
	return nil
}

func runDemo(args []string) error {
	fs := flagSet(args)
	sessionRoot := fs.String("session-root", "", "session output directory")
	if err := fs.Parse(args); err != nil {
		return err
	}
	sess, err := session.New(backends.NewDemo(), session.Options{
		Root:        *sessionRoot,
		EnableInput: true,
	})
	if err != nil {
		return err
	}
	defer sess.Close()
	obs, err := sess.Capture()
	if err != nil {
		return err
	}
	if _, err := sess.Act(map[string]any{"kind": "click", "x": 0.5, "y": 0.5}, obs["id"].(string), "demo click", "image updates"); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(sess.Summary(), "", "  ")
	fmt.Println(string(b))
	return nil
}

func runServe(args []string) error {
	fs := flagSet(args)
	port := fs.Int("port", 8765, "TCP port to bind")
	noBrowser := fs.Bool("no-browser", false, "do not auto-open the default browser")
	if err := fs.Parse(args); err != nil {
		return err
	}
	srv, err := server.Start(context.Background(), *port, !*noBrowser)
	if err != nil {
		return err
	}
	fmt.Println("KVM Agent: " + srv.URL())
	srv.Wait()
	return srv.Close()
}

func runCapture(args []string) error {
	fs := flagSet(args)
	config := commonBackendArgs(fs)
	runOCR := fs.Bool("ocr", false, "run tesseract on the captured frame and include the result")
	lang := fs.String("lang", "eng", "tesseract language code (used with --ocr)")
	checkPatterns := addPatternListFlag(fs, "check-pattern", "if non-empty, OCR the frame and exit non-zero when none of the supplied regexes match")
	caseInsensitive := fs.Bool("case-insensitive", false, "make --check-pattern matching case-insensitive")
	requireAll := fs.Bool("all-patterns", false, "require every --check-pattern regex to match")
	saveOCR := fs.String("save-ocr-json", "", "if set, write the OCR result to this path in addition to embedding it in stdout")
	if err := fs.Parse(args); err != nil {
		return err
	}
	sess, err := openSession(config.asMap())
	if err != nil {
		return err
	}
	defer sess.Close()
	obs, err := sess.Capture()
	if err != nil {
		return err
	}
	out := map[string]any{"observation": obs}
	ocrMatched := true
	if *runOCR || len(*checkPatterns) > 0 {
		o, err := ocr.Run(obs["path"].(string), ocr.Options{Language: *lang, Timeout: 30 * time.Second})
		if err != nil {
			return fmt.Errorf("capture: OCR failed: %w", err)
		}
		out["ocr"] = o
		if *saveOCR != "" {
			b, _ := json.MarshalIndent(o, "", "  ")
			if err := os.WriteFile(*saveOCR, b, 0o600); err != nil {
				return err
			}
		}
		if len(*checkPatterns) > 0 {
			results, ok, _ := textcheck.Check(*checkPatterns, o.Text, textcheck.Options{
				CaseInsensitive: *caseInsensitive,
				RequireAll:      *requireAll,
			})
			out["check"] = map[string]any{"patterns": results, "matched": ok, "all": *requireAll}
			ocrMatched = ok
		}
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	if !ocrMatched {
		return errCheckFailed
	}
	return nil
}

func runInspect(args []string) error {
	fs := flagSet(args)
	config := commonBackendArgs(fs).asMap()
	goal := fs.String("goal", "Describe visible system state and relevant text", "operator goal")
	if err := fs.Parse(args); err != nil {
		return err
	}
	sess, err := openSession(config)
	if err != nil {
		return err
	}
	defer sess.Close()
	out, err := sess.Observe(*goal, nil)
	if err != nil {
		return err
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	return nil
}

func runRun(args []string) error {
	fs := flagSet(args)
	config := commonBackendArgs(fs).asMap()
	goal := fs.String("goal", "Describe visible system state", "operator goal")
	maxSteps := fs.Int("max-steps", 10, "maximum observation/action iterations")
	execute := fs.Bool("execute", false, "dispatch actions after interpretation")
	if err := fs.Parse(args); err != nil {
		return err
	}
	sess, err := openSession(config)
	if err != nil {
		return err
	}
	defer sess.Close()
	out, err := sess.Run(*goal, *maxSteps, *execute)
	if err != nil {
		return err
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	return nil
}

func runLaunch() error {
	exe, err := vendorBinary()
	if err != nil {
		return err
	}
	cmd := exec.Command(exe)
	cmd.Env = append(os.Environ(), "QT_QPA_PLATFORM=xcb")
	if err := cmd.Start(); err != nil {
		return err
	}
	out := map[string]any{"pid": cmd.Process.Pid, "note": "run doctor after the window appears"}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	return nil
}

func runDeviceAccess() error {
	helper, err := os.Executable()
	if err != nil {
		return err
	}
	script := filepath.Join(filepath.Dir(helper), "setup-device-access")
	cmd := exec.Command("pkexec", script)
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	return cmd.Run()
}

func vendorBinary() (string, error) {
	root, err := projectRoot()
	if err != nil {
		return "", err
	}
	candidate := filepath.Join(root, "vendor", "KvmApp")
	if _, err := os.Stat(candidate); err != nil {
		return "", fmt.Errorf("vendor binary not found at %s; build the bundle first", candidate)
	}
	return candidate, nil
}

func projectRoot() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(filepath.Dir(exe)), nil
}

// --- argument parsing --------------------------------------------------

func flagSet(args []string) *flag.FlagSet {
	fs := flag.NewFlagSet("kvm-agent", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	return fs
}

// commonBackendArgs registers flags used by every backend-bearing
// subcommand and returns the parsed values.
func commonBackendArgs(fs *flag.FlagSet) *backendConfig {
	cfg := &backendConfig{}
	fs.StringVar(&cfg.backend, "backend", "demo", "backend: demo or kvmapp")
	fs.StringVar(&cfg.windowID, "window-id", "", "vendor window id for kvmapp backend")
	fs.StringVar(&cfg.viewport, "viewport", "0,0,640,480", "x,y,width,height for kvmapp backend")
	fs.StringVar(&cfg.visionURL, "vision-url", os.Getenv("KVM_VISION_URL"), "vision endpoint base URL")
	fs.StringVar(&cfg.model, "model", os.Getenv("KVM_VISION_MODEL"), "vision model name")
	fs.StringVar(&cfg.apiKey, "api-key", "", "vision API key")
	fs.StringVar(&cfg.sessionRoot, "session-root", "", "session output directory")
	fs.BoolVar(&cfg.enableInput, "enable-input", false, "permit real input dispatch")
	fs.BoolVar(&cfg.absolutMouse, "absolute-mouse", false, "kvmapp: confirm vendor GUI uses absolute mouse coordinates")
	return cfg
}

type backendConfig struct {
	backend      string
	windowID     string
	viewport     string
	visionURL    string
	model        string
	apiKey       string
	sessionRoot  string
	enableInput  bool
	absolutMouse bool
}

func (c *backendConfig) asMap() map[string]any {
	return map[string]any{
		"backend":       c.backend,
		"window_id":     c.windowID,
		"viewport":      parseInts(c.viewport),
		"vision_url":    c.visionURL,
		"model":         c.model,
		"api_key":       c.apiKey,
		"session_root":  c.sessionRoot,
		"enable_input":  c.enableInput,
		"absolute_mouse": c.absolutMouse,
	}
}

func parseInts(s string) []int {
	parts := strings.Split(s, ",")
	out := make([]int, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		n, err := strconv.Atoi(p)
		if err != nil {
			continue
		}
		out = append(out, n)
	}
	return out
}

func openSession(cfg map[string]any) (*session.Session, error) {
	name, _ := cfg["backend"].(string)
	var b backends.Backend
	switch name {
	case "demo", "":
		b = backends.NewDemo()
	case "kvmapp":
		windowID, _ := cfg["window_id"].(string)
		viewport, _ := cfg["viewport"].([]int)
		if len(viewport) != 4 {
			return nil, fmt.Errorf("viewport must have 4 integers")
		}
		absolute, _ := cfg["absolute_mouse"].(bool)
		var err error
		b, err = backends.NewKvmApp("", windowID, [4]int{viewport[0], viewport[1], viewport[2], viewport[3]}, absolute)
		if err != nil {
			return nil, err
		}
	default:
		return nil, fmt.Errorf("unknown backend %q", name)
	}
	enable, _ := cfg["enable_input"].(bool)
	opts := session.Options{
		Root:        stringFromMap(cfg, "session_root"),
		EnableInput: enable,
	}
	if url := stringFromMap(cfg, "vision_url"); url != "" {
		model := stringFromMap(cfg, "model")
		key := stringFromMap(cfg, "api_key")
		v, err := vision.NewClient(url, model, key)
		if err != nil {
			b.Close()
			return nil, err
		}
		opts.Vision = v
	}
	return session.New(b, opts)
}

func stringFromMap(m map[string]any, k string) string {
	if v, ok := m[k]; ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

// patternList is a flag.Var-compatible adapter for []string flags that may
// appear multiple times (--check-pattern X --check-pattern Y). It also
// accepts a comma-separated single argument so shell pipelines stay short.
type patternList *[]string

func addPatternListFlag(fs *flag.FlagSet, name, help string) *[]string {
	var out []string
	fs.Func(name, help, func(v string) error {
		for _, p := range strings.Split(v, ",") {
			p = strings.TrimSpace(p)
			if p != "" {
				out = append(out, p)
			}
		}
		return nil
	})
	return &out
}

// errCheckFailed is returned by runCapture / runCheckText when an
// assertion does not match; it maps to exit status 1.
var errCheckFailed = stringError("check failed")

type stringError string

func (s stringError) Error() string { return string(s) }

// runCheckText reads an OCR JSON payload from a file (or stdin) and asserts
// that one (or all) of the supplied regex patterns matches the embedded
// "text" field. Exit 0 = matched, 1 = miss, 2 = bad input.
func runCheckText(args []string) error {
	fs := flagSet(args)
	patterns := addPatternListFlag(fs, "pattern", "regex pattern to look for (repeatable)")
	caseInsensitive := fs.Bool("case-insensitive", false, "case-insensitive regex")
	requireAll := fs.Bool("all", false, "require every --pattern to match")
	fromJSON := fs.String("from-json", "", "path to the OCR JSON; default stdin")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if len(*patterns) == 0 {
		return fmt.Errorf("check-text: at least one --pattern is required")
	}
	var raw []byte
	var err error
	if *fromJSON != "" {
		raw, err = os.ReadFile(*fromJSON)
	} else {
		raw, err = io.ReadAll(os.Stdin)
	}
	if err != nil {
		return fmt.Errorf("check-text: read: %w", err)
	}
	if len(raw) == 0 {
		return fmt.Errorf("check-text: empty input")
	}
	var payload map[string]any
	text := ""
	if jerr := json.Unmarshal(raw, &payload); jerr == nil {
		text = extractText(payload)
	}
	if text == "" {
		// Tolerate raw OCR text files (no envelope).
		text = strings.TrimSpace(string(raw))
	}
	if text == "" {
		return fmt.Errorf("check-text: no text found in input")
	}
	res, ok, perr := textcheck.Check(*patterns, text, textcheck.Options{
		CaseInsensitive: *caseInsensitive,
		RequireAll:      *requireAll,
	})
	out := map[string]any{
		"patterns": res,
		"matched":  ok,
		"all":      *requireAll,
		"text_len": len(text),
	}
	if perr != nil {
		out["compile_error"] = perr.Error()
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	if !ok {
		return errCheckFailed
	}
	return nil
}

// extractText pulls the recognised text out of a capture/ocr JSON payload.
func extractText(p map[string]any) string {
	if v, ok := p["ocr"]; ok {
		if m, ok := v.(map[string]any); ok {
			if t, ok := m["text"].(string); ok {
				return t
			}
		}
	}
	if t, ok := p["text"].(string); ok {
		return t
	}
	return ""
}

// runBootIntoBios drives the supplied boot-menu key (commonly DEL or F2)
// repeatedly until OCR of the captured frame matches one of --match-text
// regexes or the overall --timeout elapses. There is intentionally no
// power-cycle step; the operator flips the test machine on by hand and
// then starts this command on the bench.
func runBootIntoBios(args []string) error {
	fs := flagSet(args)
	config := commonBackendArgs(fs)
	config.enableInput = true // pressing DEL is the whole point
	key := fs.String("key", "delete", "key to spam (logical name: delete, f2, f10, f12 ...)")
	matches := addPatternListFlag(fs, "match-text", "OCR regex indicating BIOS reached (repeatable)")
	timeout := fs.Duration("timeout", 45*time.Second, "overall time budget")
	interval := fs.Duration("interval", 250*time.Millisecond, "delay between key sends / captures")
	lang := fs.String("lang", "eng", "tesseract language")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if len(*matches) == 0 {
		*matches = []string{"Setup Utility", "BIOS Setup", "Save & Exit"}
	}
	if *interval <= 0 {
		return fmt.Errorf("boot-into-bios: interval must be positive")
	}
	if config.backend != "kvmapp" {
		return fmt.Errorf("boot-into-bios: --backend must be kvmapp")
	}
	if !config.enableInput {
		return fmt.Errorf("boot-into-bios: --enable-input is required to send key presses")
	}
	// Force enable_input even if the user forgot to pass the flag.
	cfg := config.asMap()
	cfg["enable_input"] = true
	sess, err := openSession(cfg)
	if err != nil {
		return err
	}
	defer sess.Close()

	deadline := time.Now().Add(*timeout)
	attempt := 0
	lastReport := map[string]any{}
	for {
		if time.Now().After(deadline) {
			out := map[string]any{
				"matched":    false,
				"reason":     "timeout",
				"attempts":   attempt,
				"patterns":   *matches,
				"last":       lastReport,
				"elapsed_ms": (*timeout).Milliseconds(),
			}
			b, _ := json.MarshalIndent(out, "", "  ")
			fmt.Println(string(b))
			return errCheckFailed
		}
		obs, err := sess.Capture()
		if err != nil {
			return err
		}
		o, err := ocr.Run(obs["path"].(string), ocr.Options{Language: *lang, Timeout: 5 * time.Second})
		if err != nil {
			return err
		}
		res, ok, _ := textcheck.Check(*matches, o.Text, textcheck.Options{CaseInsensitive: true})
		lastReport = map[string]any{
			"observation_id": obs["id"],
			"text_preview":   previewText(o.Text, 240),
			"matches":        res,
		}
		attempt++
		if ok {
			out := map[string]any{
				"matched":       true,
				"attempts":      attempt,
				"patterns":      res,
				"observation_id": obs["id"],
				"text_preview":  previewText(o.Text, 600),
				"elapsed_ms":    time.Since(deadline.Add(-*timeout)).Milliseconds(),
			}
			b, _ := json.MarshalIndent(out, "", "  ")
			fmt.Println(string(b))
			return nil
		}
		// Send the boot-menu key (uses Capture-then-Act; the after observation
		// is also captured+OCR'd below for the next iteration).
		if _, err := sess.Act(map[string]any{"kind": "press", "key": *key}, obs["id"].(string),
			"blind boot", "enter setup"); err != nil {
			return err
		}
		time.Sleep(*interval)
	}
}

func previewText(s string, n int) string {
	s = strings.TrimSpace(s)
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

// runPower controls a single outlet of a DLI Web Power Switch over HTTP.
// The REST API style (default) targets firmware versions that expose
// /restapi/relay/outlets/N/state. The legacy style targets URL-only
// command paths of the form /<N>On or /<N>Off used by older firmware.
func runPower(args []string) error {
	fs := flagSet(args)
	var (
		host      = fs.String("pdu-host", "", "PDU hostname or IP")
		user      = fs.String("pdu-user", os.Getenv("KVM_PDU_USER"), "PDU basic-auth user")
		pass      = fs.String("pdu-pass", os.Getenv("KVM_PDU_PASS"), "PDU basic-auth password")
		outlet    = fs.Int("pdu-outlet", 0, "outlet number (1-based)")
		action    = fs.String("pdu-action", "status", "on | off | status")
		styleStr  = fs.String("pdu-style", "rest", "rest | legacy")
		timeout   = fs.Duration("pdu-timeout", 10*time.Second, "PDU HTTP timeout")
	)
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *host == "" {
		return fmt.Errorf("power: --pdu-host is required")
	}
	if *outlet <= 0 {
		return fmt.Errorf("power: --pdu-outlet must be >= 1")
	}
	if *pass == "" {
		return fmt.Errorf("power: --pdu-pass (or KVM_PDU_PASS) is required")
	}
	style := pdu.Style(strings.ToLower(*styleStr))
	if style != pdu.StyleREST && style != pdu.StyleLegacy {
		return fmt.Errorf("power: --pdu-style must be rest or legacy")
	}
	c := &pdu.Client{
		Host:    *host,
		User:    *user,
		Pass:    *pass,
		Outlet:  *outlet,
		Style:   style,
		Timeout: *timeout,
	}
	out := map[string]any{
		"pdu_host":    *host,
		"pdu_outlet":  *outlet,
		"pdu_style":   *styleStr,
		"pdu_action":  *action,
	}
	switch strings.ToLower(*action) {
	case "on":
		if err := c.On(); err != nil {
			return fmt.Errorf("power: on: %w", err)
		}
		out["status"] = "requested on"
	case "off":
		if err := c.Off(); err != nil {
			return fmt.Errorf("power: off: %w", err)
		}
		out["status"] = "requested off"
	case "status":
		st, err := c.Status()
		if err != nil {
			out["status"] = "unknown"
			out["error"] = err.Error()
		} else {
			out["status"] = string(st)
		}
	default:
		return fmt.Errorf("power: --pdu-action must be on, off or status")
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(b))
	return nil
}

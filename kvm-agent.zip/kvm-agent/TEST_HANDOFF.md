# Test Handoff: Authoring & Deploying a kvm-agent Test for Rundeck

This document is the contract between a **human operator** (who knows the
target hardware and what "pass" looks like) and an **AI agent** (who knows
the kvm-agent CLI, the OCR / X11 mechanics, and the Rundeck job format).

The operator fills in §2. The agent follows §3-§7, runs the gates in §6,
and emits §4 (the deployable artefact). A worked example is in §9.

## 0. Prerequisites

The bench machine must already be a working kvm-agent host before any
test described here can run. See [BENCH_SETUP.md](BENCH_SETUP.md) for
the Ubuntu 24.04.4 Desktop setup (Xorg session, tesseract, udev rule,
unattended display). The handoff assumes that document has already
been followed end-to-end.

## 1. TL;DR for the operator

You provide, in plain language, five things:

1. **Targets** – which physical machines, how they are wired to the KVM.
2. **Bench node** – the Rundeck node that has the KVM USB cable + Xorg desktop.
3. **Trigger** – how to power the target on (operator button, smart PDU, BMC, …).
4. **Scope** – what state to reach (e.g. "BIOS main page") and what to assert
   (e.g. "device string `Samsung SSD 980 PRO` appears under Storage").
5. **Pass / fail criteria** – the regex(es) the OCR must (or must not) see,
   with timing budget.

Everything else is the agent's job. The agent is not allowed to invent
targets, regexes, or pass criteria; everything in the produced test must
trace back to your inputs.

## 2. Operator inputs (fill this in, send to the agent)

```yaml
test_id:                   # short unique id, e.g. "nvme-ami-v1"
description:               # one sentence: what this test proves
target_hardware:
  model:                   # e.g. "Supermicro SYS-1029P-WTRT"
  cpu:                     # optional, used for boot-menu hint
  known_bios_strings:      # regex strings you expect to see in BIOS, e.g. ["American Megatrends", "Setup Utility"]
  ports_under_test:        # list of physical ports, e.g. ["NVMe slot 0", "NVMe slot 1"]
  devices_expected:        # map of port -> expected string in BIOS UI, e.g. { "NVMe slot 0": "Samsung SSD 980 PRO" }
trigger:
  method:                  # "manual_switch" | "smart_pdu" | "ipmi"
  pdu_host:                # if smart_pdu: hostname/IP of the PDU
  pdu_user:                # if smart_pdu: PDU basic-auth user (or env KVM_PDU_USER)
  pdu_pass:                # if smart_pdu: PDU basic-auth password (or env KVM_PDU_PASS); never commit
  pdu_outlet:              # if smart_pdu: outlet number (1-based)
  pdu_style:               # if smart_pdu: "rest" (default, DLI REST API) or "legacy" (URL-only)
  bmc_host:                # if ipmi: BMC hostname/IP
  wake_delay:              # seconds to wait for the target to POST
bench:
  rundeck_node:            # node name as defined in Rundeck
  kvm_window_id_source:    # "doctor" | "static" (operator-supplied hex id)
  static_window_id:        # if "static", the literal 0x... id
  session_root:           # directory for evidence on the bench, e.g. /var/lib/rundeck/kvm
assertions:
  match_any:               # regex(s) that, if any one appears, the test passes
  match_all:               # regex(s) that ALL must appear for the test to pass
  forbid_any:              # regex(s) that, if any appears, the test fails
  timeout:                 # overall wall-clock budget, e.g. "90s"
clean_up:
  restore_default_boot:    # true if the agent should leave BIOS at defaults
  leave_power_state:       # "as_is" | "off"
notes:                     # anything else (firmware quirks, known false positives, etc.)
```

**Constraints on inputs:**

- `match_any`, `match_all`, `forbid_any` are Go regular expressions.
- At least one of `match_any` / `match_all` must be non-empty.
- `trigger.method=ipmi` requires `bmc_host`; if you cannot supply one,
  choose `manual_switch` or `smart_pdu`.
- `target_hardware.devices_expected` must have one entry per port the
  test is supposed to verify, otherwise the test cannot prove absence.

## 3. Agent workflow

The agent performs these steps in order. Each step's output is a named
artefact so the next step (or the operator) can pick up.

### Step 1 — Inputs sanity check

Reject and ask the operator before doing anything else if:

- The YAML above has missing fields, or `match_any` + `match_all` are
  both empty, or both populated.
- `trigger.method` is `ipmi` and `bmc_host` is missing.
- A `devices_expected` key is empty or duplicates another key.
- `timeout` is less than `wake_delay` plus 10 seconds.

### Step 2 — Discover bench state

Run on the bench node (via Rundeck's local-exec step, or via SSH from
the agent):

```
kvm-agent doctor > /tmp/<test_id>/doctor.json
```

The doctor JSON records X11 availability, the list of `/dev/videoN`
nodes, the list of vendor windows (`kvmapp_windows`), the X session type,
and the `direct_hid_forwarding` note.

If `bench.kvm_window_id_source == "doctor"`, pick the window id from
`kvmapp_windows[0].window_id`. If `static_window_id` is set, validate it
appears in `kvmapp_windows`; abort otherwise.

### Step 3 — Author the test script

Use the template in §4. The script is **the only** file the agent
emits. Do not also emit loose JSON snippets — Rundeck expects one
executable per job step.

### Step 4 — Local dry run (if a target is reachable)

If the bench has a vendor window at this moment, run the script with
`--dry-run` (an agent convention; not built into kvm-agent yet — see
§10). A dry run captures each step but does not require the target
device string to be present.

### Step 5 — Verification gates

Run every gate in §6. Each gate must pass. If any fails, fix the
script and re-run.

### Step 6 — Deploy

Apply the test to Rundeck per §7. Record the Rundeck job id in
`/etc/kvm-agent/tests/<test_id>.deployed` on the bench node.

### Step 7 — Smoke run from Rundeck

Trigger the deployed job once. Verify:

- The job returns exit 0.
- The evidence directory contains `events.jsonl`, `summary.json`,
  PNGs, and that `summary.json.session_id` is recorded in the job log.

If the smoke run fails, do not declare the test deployed. Roll back per §8.

## 4. Output template (what the agent produces)

The agent emits one Bash script, `tests/<test_id>/run.sh`, that:

- Returns exit 0 on pass, 1 on fail, 2 on harness error.
- Writes all evidence to `$KVM_SESSION_ROOT/<test_id>-<utc>/`.
- Logs every step to a single file the operator can `tail -f`.
- Uses only the kvm-agent CLI + tesseract + standard shell utilities.

```bash
#!/usr/bin/env bash
# Auto-generated by kvm-agent TEST_HANDOFF.md workflow.
# test_id:           <test_id>
# description:       <description>
# target:            <target_hardware.model>
# generated_utc:     <...>
set -euo pipefail

WID="${WID:-0x$(jq -r '.kvmapp_windows[0].window_id' /tmp/<test_id>/doctor.json | sed 's/^0x//')}"
VIEWPORT="${VIEWPORT:-$(jq -r '.kvmapp_windows[0].client_size | "\(.[0]),\(.[1]),640,480"' /tmp/<test_id>/doctor.json)}"
SESSION_ROOT="${KVM_SESSION_ROOT:-/var/lib/rundeck/kvm/<test_id>}"
mkdir -p "$SESSION_ROOT"

log() { printf '[date=%s] %s\n' "$(date -u +%FT%TZ)" "$*" >&2; }
fail() { log "FAIL: $*"; exit 1; }
trap 'log "harness error on line $LINENO"' ERR

# Step A: enter the BIOS
kvm-agent boot-into-bios \
    --backend kvmapp --window-id "$WID" --viewport $VIEWPORT \
    --key delete --interval 250ms --timeout <timeout> \
    --match-text '<compiled match_all|match_any alternation>' \
    > "$SESSION_ROOT/boot.json" || fail "BIOS not detected"

# Step B: navigate to the storage page
# (agent composes this from operator's notes / known_bios_strings)

# Step C: capture + assert
OUT=$(kvm-agent capture \
    --backend kvmapp --window-id "$WID" --viewport $VIEWPORT \
    --session-root "$SESSION_ROOT" \
    --check-pattern '<compiled match_all|match_any alternation>' \
    --check-pattern '<forbid_any alternation inverted to negative match>' \
    --case-insensitive)
echo "$OUT" | jq . > "$SESSION_ROOT/capture.json"

log "PASS: <test_id>"
exit 0
```

The agent may also emit:

- `tests/<test_id>/README.md` – human description of the test.
- `tests/<test_id>/invariants.sh` – the small piece that the agent
  derived from the operator's YAML (regex compilation, viewport
  derivation). Read this when you want to know what the test is actually
  asserting.

## 5. Test design patterns

The agent picks a pattern based on the operator's `description`:

### A. "Is X visible in BIOS?"

Default pattern. Use `boot-into-bios` to enter Setup, then `capture
--check-pattern` against the operator's `devices_expected` strings.
Combine with `forbid_any` (e.g. `"Not Detected"`, `"Empty"`) to make a
present green.

### B. "Does the target boot into OS X?"

`boot-into-bios` followed by scripted navigation that exits Setup
("Save & Exit → Boot Override" or similar). Then `capture` in a loop
until a known OS string appears in the OCR text. Use `forbid_any` for
grub rescue / kernel panic strings.

### C. "Does the target enumerate a USB device Y?"

Pattern A but on the OS desktop. No `boot-into-bios` step; instead wait
for OS login, then `capture` against the operator's expected `lsusb`
output rendered in a terminal.

### D. "Is firmware version F running?"

Capture the BIOS main page, then `capture --check-pattern` for the
firmware version string. Combine with `forbid_any` for known-bad
versions.

If the operator's spec does not match any of A-D, the agent pauses and
asks the operator for a clarifier before authoring the test.

## 6. Verification gates (agent must pass all)

The agent runs these on the bench before declaring the test ready:

- [ ] **Regex compiles**: `grep -E '<pattern>' < /dev/null` exits 0 for
  every pattern in `match_any`, `match_all`, `forbid_any`. (Use `go run`
  on a tiny snippet, or `rg --pcre2` if available.)
- [ ] **Window id resolves**: `kvm-agent doctor` returns a non-empty
  `kvmapp_windows` array on the bench.
- [ ] **Tesseract is present**: `tesseract --version` exits 0.
- [ ] **Capture round-trip**: `kvm-agent capture --backend kvmapp …
  --ocr` returns JSON, exits 0, leaves a non-empty PNG in the session
  directory.
- [ ] **Negative path**: with a known-absent pattern (e.g. "ZZZ_NO_MATCH"),
  `capture --check-pattern "ZZZ_NO_MATCH"` exits 1 within 30 s.
- [ ] **Positive path**: with a known-present pattern (substring of the
  doctor's own OCR), `capture --check-pattern "Setup|Utility|Configuration"`
  exits 0.
- [ ] **Forbidden path**: `forbid_any` patterns would cause exit 1 if
  matched. The agent should write a unit-style test for the textcheck
  package that proves this without needing a real target.
- [ ] **No upstream references**: `grep -Rni "<UPSTREAM_PROJECT_NAME>"`
  over the produced test directory returns 0 hits. The agent substitutes
  the appropriate pattern (e.g. the original SDK / GUI project's name)
  based on its environment rules.
- [ ] **Permissions**: the script is `chmod 0755`; the session root is
  created `0700`; evidence files are written `0600`.

If any gate fails, fix the script and re-run the gates. Do not deploy
a partially-passing test.

## 7. Deployment procedure

```bash
# 1. Drop the test on the bench.
scp -r tests/<test_id>/ rundeck@<bench>:/etc/kvm-agent/tests/<test_id>/

# 2. Run the gates one more time on the bench.
ssh rundeck@<bench> /etc/kvm-agent/tests/<test_id>/run.sh --self-check

# 3. Create the Rundeck job. Use the project's `rundeck-template.xml`
#    (or, if absent, the inline YAML below) and substitute <test_id>,
#    <description>, <bench.rundeck_node>.

# 4. Tag the deployment.
ssh rundeck@<bench> tee /etc/kvm-agent/tests/<test_id>.deployed <<EOF
job_id:    <RD_JOB_UUID>
deployed_utc: $(date -u +%FT%TZ)
EOF
```

A minimal Rundeck job definition (YAML) for the inline form:

```yaml
- defaultTab: summary
  description: <description>
  executionEnabled: true
  group: kvm-agent/<test_id>
  name: kvm-agent.<test_id>
  nodeStepBehavior: true
  sequence:
    commands:
    - description: Run the kvm-agent test
      script: |
        #!/usr/bin/env bash
        set -euo pipefail
        exec /etc/kvm-agent/tests/<test_id>/run.sh
    - description: Publish evidence
      script: |
        #!/usr/bin/env bash
        # Tar the session directory and attach to the Rundeck job log
        tar -C "$(dirname "$RD_JOB_SCRIPT_LOG_FILE")" -cf - .
  nodesSelectedByScript: true
  script: |
    echo '<bench.rundeck_node>'
```

## 8. Rollback procedure

```bash
# Stop any running instance of the job.
# (Rundeck UI or: rd job run -j <job_id> --halt)

# Delete the Rundeck job.
rd job delete -y -j <job_id>

# Remove the bench artefact.
ssh rundeck@<bench> rm -rf /etc/kvm-agent/tests/<test_id> \
    /etc/kvm-agent/tests/<test_id>.deployed
```

The session evidence directories under `KVM_SESSION_ROOT` are kept by
default; the operator may delete them once the rollback is confirmed.

## 9. Worked example: BIOS NVMe detection

### Operator input

```yaml
test_id: nvme-bootmenu-v1
description: Verify Samsung SSD 980 PRO is visible in the one-time Boot Manager of a Supermicro SYS-1029P-WTRT, no BMC.
target_hardware:
  model: Supermicro SYS-1029P-WTRT
  cpu: Intel Xeon Silver 4214
  known_bios_strings: ["American Megatrends", "Boot Manager", "Please select"]
  ports_under_test: ["NVMe slot 0"]
  devices_expected:
    "NVMe slot 0": "Samsung SSD 980 PRO"
trigger:
  method: smart_pdu
  pdu_host: 192.168.1.50
  pdu_user: admin
  pdu_pass: ${KVM_PDU_PASS}        # provided via env var, never commit
  pdu_outlet: 3
  pdu_style: rest                   # modern DLI Web Power Switch REST API
  wake_delay: 25s
bench:
  rundeck_node: bench-a
  kvm_window_id_source: doctor
  session_root: /var/lib/rundeck/kvm
assertions:
  match_any:
    - "Boot Manager"
    - "Please select"
  match_all: []
  forbid_any:
    - "Not Detected"
    - "No NVMe device found"
  timeout: 120s
clean_up:
  restore_default_boot: false
  leave_power_state: off
notes: ESC spam enters one-time boot menu on this board; the actual BIOS
  Setup Utility requires DEL. Vendor window id drifts between reboots.
```

### Agent-produced script (key parts)

```bash
set -euo pipefail
WID=$(jq -r '.kvmapp_windows[0].window_id' /tmp/nvme-bootmenu-v1/doctor.json)
VIEWPORT=$(jq -r '.kvmapp_windows[0].client_size | "\(.[0]),\(.[1]),640,480"' /tmp/nvme-bootmenu-v1/doctor.json)
SESSION_ROOT="/var/lib/rundeck/kvm/nvme-bootmenu-v1-$(date -u +%FT%H%MZ)"
mkdir -p "$SESSION_ROOT"

# 1. Power on the target via DLI WPS (no BMC).
kvm-agent power \
    --pdu-host 192.168.1.50 \
    --pdu-user "$KVM_PDU_USER" \
    --pdu-pass "$KVM_PDU_PASS" \
    --pdu-outlet 3 \
    --pdu-action on \
    --pdu-style rest || { echo 'PDU on failed'; exit 1; }

# 2. Wait for the target to POST.
sleep "${WAKE_DELAY:-25s}"

# 3. Spam ESC until OCR sees the one-time Boot Manager (or "Please
#    select"). boot-into-bios is the right primitive even though the
#    target is not the BIOS Setup: the loop is generic over key + text.
kvm-agent boot-into-bios \
    --backend kvmapp --window-id "$WID" --viewport $VIEWPORT \
    --key esc --interval 250ms --timeout 60s \
    --match-text 'Boot Manager' \
    --match-text 'Please select' \
    --session-root "$SESSION_ROOT" || {
    echo 'Boot Manager not detected via OCR'; exit 1; }

# 4. The operator's notes say the NVMe slot 0 entry appears as a row
#    in the boot menu. We dispatch a few navigation keys so the agent's
#    evidence ledger shows the path, then OCR-assert.
# (No-op navigation here; the device string is the boot entry itself.)

# 5. Assert the NVMe device is listed, and the absence strings are not.
kvm-agent capture \
    --backend kvmapp --window-id "$WID" --viewport $VIEWPORT \
    --session-root "$SESSION_ROOT" \
    --check-pattern 'Samsung SSD 980 PRO' \
    --check-pattern 'Not Detected' \
    --check-pattern 'No NVMe device found' \
    --case-insensitive || {
    echo '==== FAIL: NVMe not detected in Boot Manager ===='
    jq '.ocr' "$SESSION_ROOT"/*/events.jsonl 2>/dev/null | head -50
    exit 1; }

# 6. Clean up: leave the target off, leave the vendor window as-is.
kvm-agent power --pdu-host 192.168.1.50 --pdu-user "$KVM_PDU_USER" \
    --pdu-pass "$KVM_PDU_PASS" --pdu-outlet 3 --pdu-action off || true
```

The same flow also runs unattended from Rundeck because every step
exits 0 on success and 1 on failure, and every step's stdout is JSON
that Rundeck captures into the job log.


Note the absence-negation pattern: every "not detected" string is
included as a `--check-pattern`; if any matches, the command exits 1,
which is the desired behaviour. This works because `capture
--check-pattern` defaults to "any match → pass" and the agent inverts
that semantic by including the forbid set in the same call. (An
explicit `--forbid-pattern` flag is on the roadmap; see §10.)

## 10. Known limitations and roadmap

- `--forbid-pattern` flag is planned; until it ships, forbid-set is
  implemented as additional `--check-pattern` entries combined with
  `--all-patterns` in a wrapper step.
- `--dry-run` mode is not yet built into kvm-agent. Today the agent
  validates by hitting real vendor windows; that is acceptable because
  the bench is dedicated test hardware.
- Multi-monitor X servers sometimes place the vendor window on a
  non-default screen. The agent should pass `--display :0.1` etc.
  via the env var when the bench reports `screens > 1`.
- The agent must not assume `doctor` returns the same window id between
  reboots. Always re-query.


## 12. Power control: `kvm-agent power`

The optional `power` subcommand talks to a Digital Loggers Inc Web
Power Switch over HTTP. Two firmware styles are supported:

| Style   | Endpoint                                                   |
|---------|------------------------------------------------------------|
| `rest`  | `GET /restapi/relay/outlets/<n>/state?value=0\|1`          |
| `legacy`| `GET /<n>On` or `GET /<n>Off`                              |

```sh
kvm-agent power --pdu-host 192.168.1.50 \
    --pdu-user admin --pdu-pass "$KVM_PDU_PASS" \
    --pdu-outlet 3 --pdu-action on --pdu-style rest

kvm-agent power --pdu-host 192.168.1.50 \
    --pdu-user admin --pdu-pass "$KVM_PDU_PASS" \
    --pdu-outlet 3 --pdu-action status

kvm-agent power --pdu-host 192.168.1.50 \
    --pdu-user admin --pdu-pass "$KVM_PDU_PASS" \
    --pdu-outlet 3 --pdu-action off --pdu-style legacy
```

The credentials can come from `--pdu-pass` / `--pdu-user` or from the
`KVM_PDU_PASS` / `KVM_PDU_USER` environment variables. **Never commit a
PDU password**; pass it via the Rundeck job's secure option or via the
bench user's environment. The command returns exit 0 on a 2xx response,
exit 1 with a JSON error body on any failure (unreachable host, HTTP
error, missing credentials), so a Rundeck job step treats it as a
native pass/fail gate.

## 11. Glossary

- **bench**: the Rundeck node that owns the KVM USB hardware.
- **target**: the physical machine under test.
- **vendor window**: the X11 window owned by the vendor's video
  application (KvmApp).
- **viewport**: the rectangle inside the vendor window that contains
  the remote video. Set once per bench session.
- **assertion**: a Go regex applied to OCR text from a captured frame.

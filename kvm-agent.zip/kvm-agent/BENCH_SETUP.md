# kvm-agent Bench Setup (Ubuntu 24.04.4 Desktop, Xorg)

This runbook takes a **default install of Ubuntu 24.04.4 Desktop** (GNOME on
Wayland) and turns it into a working kvm-agent test bench. The kvm-agent
binary already shipped, but the bench machine needs to:

1. Boot into a GNOME Xorg session (Wayland is rejected by the vendor
   backend because it lacks the XTEST extension).
3. Have `tesseract` on `PATH` for the OCR-driven assertions.
4. Allow the active local user to read the Epiphan USB endpoints
   (udev rule, no world-writable permissions).
5. Not lock, blank, or sleep the screen during unattended test runs.

Total wall time: ~15 minutes plus one reboot.

## Prerequisites

- Physical or VM access to the bench with `sudo`.
- A user account (created during the Ubuntu install) that will own the
  bench session. Used below as `<bench-user>`.
- The Epiphan KVM2USB 3.0 host cable, the target video cable and the
  target USB cable physically connected to the bench.
- The DLI Web Power Switch's hostname/IP and outlet number, if the test
  flow will exercise the `power` subcommand.
- Network access from the bench to a vision LLM endpoint (only required
  for the `inspect` and `run` subcommands; OCR tests do not need it).

## Step 1 — Disable Wayland, set the default session to Xorg

The default `/etc/gdm/custom.conf` looks like:

```ini
[daemon]
# Uncomment the line below to force the login screen to use Xorg
#WaylandEnable=false
```

Edit it to:

```ini
[daemon]
WaylandEnable=false
DefaultSession=ubuntu-xorg.desktop
```

The `DefaultSession=` line is the one people miss. Without it, GDM may
pick the Wayland option after a reboot when no user preference is yet
recorded.

```sh
sudo sed -i 's/^#WaylandEnable=false/WaylandEnable=false/' /etc/gdm/custom.conf
echo -e "\nDefaultSession=ubuntu-xorg.desktop" | sudo tee -a /etc/gdm/custom.conf
sudo reboot
```

After the reboot, log in normally and verify:

```sh
echo $XDG_SESSION_TYPE    # must print: x11
echo $XDG_CURRENT_DESKTOP # ubuntu:GNOME  (the DE does not change, only the display server)
loginctl show-session "$(loginctl | awk '/seat0/ {print $1}')" -p Type   # x11
```

If `XDG_SESSION_TYPE` still says `wayland`, the change did not take
effect (you didn't reboot, or you logged in via a fallback). Re-check
`/etc/gdm/custom.conf` and reboot again.

## Step 2 — Install `tesseract`

The OCR-driven assertions in `kvm-agent capture --ocr`,
`kvm-agent check-text` and `kvm-agent boot-into-bios` shell out to the
`tesseract` binary. Without it, the relevant subcommands return
`tesseract binary not found on PATH` as a clean dependency error
instead of timing out.

```sh
sudo apt update
sudo apt install -y tesseract-ocr tesseract-ocr-eng
tesseract --version
```

Add additional language packs as needed, e.g.
`tesseract-ocr-deu`, `tesseract-ocr-fra`. They live under
`/usr/share/tesseract-ocr/<lang>.traineddata` and are selected with
`--lang` on `capture` / `boot-into-bios`.

## Step 3 — Install `kvm-agent`

From a portable bundle:

```sh
sudo install -d /opt/kvm-agent
sudo cp -r EpiphanAgent/* /opt/kvm-agent/
sudo ln -sf /opt/kvm-agent/kvm-agent /usr/local/bin/kvm-agent
```

Or build from source on the bench:

```sh
cd /path/to/kvm-agent-source
go build -o kvm-agent ./cmd/kvm-agent
sudo install -m 0755 kvm-agent /usr/local/bin/kvm-agent
```

Verify:

```sh
kvm-agent doctor
# expect: platform=linux, session_type=x11, display_error=null
```

## Step 4 — Prevent the screen from locking or blanking

GNOME locks the screen after idle, and the Xorg DPMS timeout blanks
the display. Both prevent unattended capture on a long test run.

```sh
gsettings set org.gnome.desktop.session idle-delay 0
gsettings set org.gnome.desktop.screensaver lock-enabled false
gsettings set org.gnome.desktop.privacy disable-lock-screen true
xset -dpms
xset s off
```

`xset` only affects the current X session; if the bench reboots, set
it via `~/.xprofile` or run it once after each login. The `gsettings`
keys persist.

If using autologin (see next), the lock setting is not strictly
necessary because no human is around to unlock — but the blank/DPMS
settings still matter for capture quality.

## Step 5 — (Optional) Enable autologin for unattended Rundeck runs

Only enable this if the box is in a physically locked rack and you are
comfortable with whoever has power-on access owning the desktop
session.

Create the bench user if it does not exist:

```sh
sudo useradd -m -d /var/lib/rundeck -s /bin/bash rundeck
sudo passwd rundeck
```

Append to `/etc/gdm/custom.conf`:

```ini
[daemon]
AutomaticLoginEnable=true
AutomaticLogin=rundeck
AutomaticLoginDelay=5
```

(The `WaylandEnable=false` and `DefaultSession=ubuntu-xorg.desktop`
lines from Step 1 stay in the same `[daemon]` section.)

Reboot; the bench should land directly in the Xorg session as the
`rundeck` user.

## Step 6 — Install the udev rule for USB device access

Without this, `/dev/videoN` and `/dev/hidrawN` are readable only by
root and capture fails with `permission denied`. The rule uses
`TAG+="uaccess"` so the active local user gets exclusive access via
logind, rather than world-writable permissions.

Either invoke the helper shipped with the project:

```sh
sudo kvm-agent setup-device-access
```

…which wraps the install behind `pkexec` and gives the operator a
graphical auth prompt the first time. The helper refuses to overwrite
a differing existing rule.

Or install manually:

```sh
sudo install -m 0644 70-kvm-agent.rules /etc/udev/rules.d/70-kvm-agent.rules
sudo udevadm control --reload-rules
```

After installing the rule, **unplug and replug** the Epiphan host USB
cable so the device re-enumerates against the new rule.

Confirm the bench user can read the device nodes:

```sh
ls -l /dev/video* /dev/hidraw* 2>/dev/null
# the active local user should be the group owner, or the file should
# carry the uaccess tag (visible in `ls -l` as a "+" at the end of
# the mode bits).
```

## Step 7 — Smoke test the full stack

Run these on the bench in an Xorg session, with the Epiphan host USB
cable plugged in and the vendor GUI launched.

```sh
# 7.1. Synthetic capture exercises capture / act / OCR / check without hardware.
kvm-agent demo --session-root /var/lib/rundeck/kvm-smoke

# 7.2. Real environment: confirm vendor window is reachable.
kvm-agent doctor
# Look for a non-empty kvmapp_windows array and no display_error.

# 7.3. Real capture against the vendor window. Replace WID with the
#      value from doctor; the window id drifts between reboots.
WID=$(kvm-agent doctor | jq -r '.kvmapp_windows[0].window_id')
kvm-agent capture --backend kvmapp \
    --window-id "$WID" --viewport 0 0 1280 720 \
    --ocr --save-ocr-json /tmp/smoke-ocr.json \
    --session-root /var/lib/rundeck/kvm-smoke

# 7.4. OCR assert something visible (replace with a string you know is on screen).
kvm-agent check-text --pattern 'KvmApp|Main|Setup' \
    --from-json /tmp/smoke-ocr.json --case-insensitive
# exit 0 = pass, 1 = miss
```

If 7.1 produces a demo PNG, 7.3 returns OCR text, and 7.4 exits 0, the
bench is ready. Save this sequence as
`/etc/kvm-agent/tests/smoke/run.sh` so any Rundeck job can call it as
a regression check.

## Step 8 — Pin `gdm3`

GNOME Software updates can quietly re-enable Wayland when `gdm3` is
upgraded. Once everything is working:

```sh
sudo apt-mark hold gdm3
```

Review changelogs before allowing future upgrades.

## Troubleshooting

The kvm-agent fails with a `vendor window failed to receive focus`
error. Mutter on Xorg has focus-stealing prevention that sometimes
yanks focus back right after the agent's `SetInputFocus`. Click on the
vendor window once by hand before the test run; the per-capture focus
re-assertion then lands cleanly. Long-term fix:
`gsettings set org.gnome.desktop.wm.preferences focus-new-windows strict`
or replace GNOME with i3 on the bench.

Hotkeys like `Super+Tab` or `Alt+Tab` never reach the vendor window.
These are grabbed by gnome-shell at the compositor level before the
XTEST dispatch. The action validator already rejects `super` in
hotkeys; if you bypass that for a specific test, expect those keys to
be eaten by the shell. Use plain `Ctrl`, `Alt`, `Shift` only.

Accessibility features (Sticky Keys, Slow Keys, gnome-mag) intercept
keys at the X server level and pre-empt XTEST. Disable them in
*Settings → Accessibility* before a test run.

Vendor window id changes between reboots. Don't hard-code it; always
re-query via `kvm-agent doctor` at the start of every Rundeck job.
The test handoff document already mandates this.

`kvm-agent` returns `tesseract binary not found on PATH`. Either
install tesseract (Step 2) or treat the test as vision-only and rely
on the vision LLM for interpretation. The OCR path is the
deterministic one for CI; the vision LLM is for navigation in
unfamiliar UIs.

`kvm-agent power` returns `pdu: unreachable`. Confirm the bench can
reach the DLI WPS on TCP/80, and that the basic-auth credentials are
correct. `curl -u admin:1234 http://192.168.1.50/restapi/relay/outlets/3/state`
is a useful manual probe.

The screen blanks mid-capture. DPMS is still enabled — re-run
`xset -dpms; xset s off` and persist them in `~/.xprofile` so they
re-apply after every reboot.

## Optional hardening

Switch the bench to i3 instead of GNOME:
`sudo apt install i3` and pick "i3" at the GDM gear menu after
disabling Wayland. No Mutter focus-stealing, no accessibility
key-grabbing, no Super-key conflicts. kvm-agent does not care which
window manager runs; it talks directly to the X server. For a serious
KVM automation bench this is the conventional choice; GNOME is fine
for occasional runs, painful for steady CI.

Persist the X11-level screen blanking settings via systemd user
service so they re-apply regardless of who logs in:

```ini
# ~/.config/systemd/user/kvm-bench-display.service
[Unit]
Description=Disable DPMS and screen blanking for the bench session
After=graphical.target

[Service]
Type=oneshot
ExecStart=/usr/bin/xset -dpms
ExecStart=/usr/bin/xset s off
RemainAfterExit=yes

[Install]
WantedBy=default.target
```

```sh
systemctl --user enable kvm-bench-display.service
```

Schedule a `kvm-agent doctor` smoke check in cron (or as a Rundeck
scheduled job) every 15 minutes; on failure, page the on-call so the
bench does not silently rot.
